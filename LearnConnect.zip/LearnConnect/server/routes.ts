import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import express from "express";
import { z } from "zod";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";
import { 
  insertUserSchema, insertCourseSchema, insertEnrollmentSchema, 
  insertAssignmentSchema, insertSubmissionSchema, insertAnnouncementSchema, 
  insertResourceSchema, insertEventSchema, insertMessageSchema
} from "@shared/schema";

// Extend Express Request interface
declare global {
  namespace Express {
    interface Request {
      user?: {
        id: number;
        username: string;
        name: string;
        email: string;
        role: string;
        profileImage?: string;
      };
      session: any;
    }
  }
}

// Auth middleware
const authenticateUser = async (req: Request, res: Response, next: Function) => {
  const userId = req.session?.userId;
  
  if (!userId) {
    return res.status(401).json({ message: "Unauthorized - Please login" });
  }
  
  const user = await storage.getUser(Number(userId));
  if (!user) {
    return res.status(401).json({ message: "Unauthorized - User not found" });
  }
  
  req.user = {
    id: user.id,
    username: user.username,
    name: user.name,
    email: user.email,
    role: user.role,
    profileImage: user.profileImage
  };
  
  next();
};

// Role-based access middleware
const requireRole = (roles: string[]) => {
  return (req: Request, res: Response, next: Function) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({ message: "Forbidden - Insufficient permissions" });
    }
    next();
  };
};

// Import session modules
import session from "express-session";
import createMemoryStore from "memorystore";

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up sessions
  const MemoryStore = createMemoryStore(session);
  
  app.use(
    session({
      cookie: { maxAge: 86400000 }, // 24 hours
      store: new MemoryStore({
        checkPeriod: 86400000, // prune expired entries every 24h
      }),
      resave: false,
      secret: process.env.SESSION_SECRET || "educonnect_secret",
      saveUninitialized: false,
    })
  );

  // Set up API routes

  // Setup API routes
  const router = express.Router();

  // Error handler for zod validation
  const validateRequest = (schema: z.ZodType<any, any>) => {
    return (req: Request, res: Response, next: Function) => {
      try {
        req.body = schema.parse(req.body);
        next();
      } catch (error) {
        if (error instanceof ZodError) {
          const validationError = fromZodError(error);
          res.status(400).json({ message: validationError.message });
        } else {
          res.status(500).json({ message: "Internal server error during validation" });
        }
      }
    };
  };

  // ===== Auth Routes =====
  router.post("/auth/login", async (req, res) => {
    const loginSchema = z.object({
      username: z.string().min(1, "Username is required"),
      password: z.string().min(1, "Password is required"),
    });

    try {
      const { username, password } = loginSchema.parse(req.body);
      
      const user = await storage.getUserByUsername(username);
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid username or password" });
      }
      
      // Set user in session
      req.session.userId = user.id;
      
      res.json({
        id: user.id,
        username: user.username,
        name: user.name,
        email: user.email,
        role: user.role,
        profileImage: user.profileImage
      });
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        res.status(400).json({ message: validationError.message });
      } else {
        res.status(500).json({ message: "Internal server error" });
      }
    }
  });

  router.post("/auth/register", validateRequest(insertUserSchema), async (req, res) => {
    try {
      // Check if username already exists
      const existingUser = await storage.getUserByUsername(req.body.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already taken" });
      }
      
      const user = await storage.createUser(req.body);
      
      // Set user in session
      req.session.userId = user.id;
      
      res.status(201).json({
        id: user.id,
        username: user.username,
        name: user.name,
        email: user.email,
        role: user.role,
        profileImage: user.profileImage
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to create user" });
    }
  });

  router.post("/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Failed to logout" });
      }
      
      res.json({ message: "Logged out successfully" });
    });
  });

  router.get("/auth/me", authenticateUser, (req, res) => {
    res.json(req.user);
  });

  // ===== Dashboard Routes =====
  router.get("/dashboard/stats", authenticateUser, async (req, res) => {
    try {
      const userId = req.user?.id;
      if (!userId) return res.status(401).json({ message: "Unauthorized" });
      
      // Get assignments with status
      const assignments = await storage.getAssignmentsByStudent(userId);
      const upcomingAssignments = assignments.filter(
        a => a.status !== 'completed' && a.status !== 'submitted' && a.status !== 'graded'
      ).length;
      
      // Get today's classes
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const tomorrow = new Date(today);
      tomorrow.setDate(tomorrow.getDate() + 1);
      
      const events = await storage.getEventsByUser(userId);
      const todayClasses = events.filter(
        e => e.startTime >= today && e.startTime < tomorrow
      ).length;
      
      // Get unread messages
      const unreadMessages = await storage.getUnreadMessageCount(userId);
      
      // Get new grades (assignments that have been graded but not viewed)
      const submissions = await storage.getSubmissionsByUser(userId);
      const newGrades = submissions.filter(s => s.grade !== null).length;
      
      res.json({
        upcomingAssignments,
        todayClasses,
        unreadMessages,
        newGrades
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  // ===== User Routes =====
  router.get("/users/:id", authenticateUser, async (req, res) => {
    try {
      const user = await storage.getUser(Number(req.params.id));
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Don't return password
      const { password, ...userData } = user;
      res.json(userData);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  router.put("/users/:id", authenticateUser, async (req, res) => {
    try {
      const userId = Number(req.params.id);
      
      // Users can only update their own profile unless they're an admin
      if (req.user?.id !== userId && req.user?.role !== 'admin') {
        return res.status(403).json({ message: "Forbidden - You can only update your own profile" });
      }
      
      const updateSchema = z.object({
        name: z.string().optional(),
        email: z.string().email().optional(),
        profileImage: z.string().optional().nullable(),
      });
      
      const userData = updateSchema.parse(req.body);
      const updatedUser = await storage.updateUser(userId, userData);
      
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Don't return password
      const { password, ...userResponse } = updatedUser;
      res.json(userResponse);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        res.status(400).json({ message: validationError.message });
      } else {
        res.status(500).json({ message: "Failed to update user" });
      }
    }
  });

  // ===== Course Routes =====
  router.get("/courses", authenticateUser, async (req, res) => {
    try {
      const userId = req.user?.id;
      if (!userId) return res.status(401).json({ message: "Unauthorized" });
      
      const user = await storage.getUser(userId);
      let courses;
      
      if (user?.role === 'teacher') {
        courses = await storage.getCoursesByTeacher(userId);
        
        // Get teachers for courses
        const coursesWithTeacher = await Promise.all(courses.map(async (course) => {
          const teacher = await storage.getUser(course.teacherId);
          return {
            ...course,
            teacher: teacher ? { 
              id: teacher.id, 
              name: teacher.name,
              profileImage: teacher.profileImage 
            } : null
          };
        }));
        
        res.json(coursesWithTeacher);
      } else {
        courses = await storage.getCoursesByStudent(userId);
        
        // Get teachers for courses
        const coursesWithTeacher = await Promise.all(courses.map(async (course) => {
          const teacher = await storage.getUser(course.teacherId);
          return {
            ...course,
            teacher: teacher ? { 
              id: teacher.id, 
              name: teacher.name,
              profileImage: teacher.profileImage 
            } : null
          };
        }));
        
        res.json(coursesWithTeacher);
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch courses" });
    }
  });

  router.get("/courses/:id", authenticateUser, async (req, res) => {
    try {
      const courseId = Number(req.params.id);
      const course = await storage.getCourse(courseId);
      
      if (!course) {
        return res.status(404).json({ message: "Course not found" });
      }
      
      // Get teacher
      const teacher = await storage.getUser(course.teacherId);
      
      // Check if user is enrolled or is the teacher
      const userId = req.user?.id;
      const isTeacher = userId === course.teacherId;
      const enrollment = userId ? await storage.getEnrollment(courseId, userId) : null;
      
      const courseWithDetails = {
        ...course,
        teacher: teacher ? { 
          id: teacher.id, 
          name: teacher.name,
          profileImage: teacher.profileImage 
        } : null,
        isEnrolled: Boolean(enrollment),
        progress: enrollment?.progress || 0,
        role: isTeacher ? 'teacher' : 'student'
      };
      
      res.json(courseWithDetails);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch course" });
    }
  });

  router.post("/courses", authenticateUser, requireRole(['teacher', 'admin']), validateRequest(insertCourseSchema), async (req, res) => {
    try {
      const course = await storage.createCourse({
        ...req.body,
        teacherId: req.user?.id || req.body.teacherId
      });
      
      res.status(201).json(course);
    } catch (error) {
      res.status(500).json({ message: "Failed to create course" });
    }
  });

  router.put("/courses/:id", authenticateUser, async (req, res) => {
    try {
      const courseId = Number(req.params.id);
      const course = await storage.getCourse(courseId);
      
      if (!course) {
        return res.status(404).json({ message: "Course not found" });
      }
      
      // Only teacher of the course or admin can update
      if (req.user?.id !== course.teacherId && req.user?.role !== 'admin') {
        return res.status(403).json({ message: "Forbidden - You don't have permission to update this course" });
      }
      
      const updateSchema = z.object({
        name: z.string().optional(),
        description: z.string().optional().nullable(),
        color: z.string().optional(),
        icon: z.string().optional()
      });
      
      const courseData = updateSchema.parse(req.body);
      const updatedCourse = await storage.updateCourse(courseId, courseData);
      
      if (!updatedCourse) {
        return res.status(404).json({ message: "Course not found" });
      }
      
      res.json(updatedCourse);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        res.status(400).json({ message: validationError.message });
      } else {
        res.status(500).json({ message: "Failed to update course" });
      }
    }
  });

  router.delete("/courses/:id", authenticateUser, requireRole(['teacher', 'admin']), async (req, res) => {
    try {
      const courseId = Number(req.params.id);
      const course = await storage.getCourse(courseId);
      
      if (!course) {
        return res.status(404).json({ message: "Course not found" });
      }
      
      // Only teacher of the course or admin can delete
      if (req.user?.id !== course.teacherId && req.user?.role !== 'admin') {
        return res.status(403).json({ message: "Forbidden - You don't have permission to delete this course" });
      }
      
      const success = await storage.deleteCourse(courseId);
      
      if (!success) {
        return res.status(404).json({ message: "Course not found" });
      }
      
      res.json({ message: "Course deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete course" });
    }
  });

  // ===== Enrollment Routes =====
  router.post("/courses/:id/enroll", authenticateUser, async (req, res) => {
    try {
      const courseId = Number(req.params.id);
      const userId = req.user?.id;
      
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      // Check if course exists
      const course = await storage.getCourse(courseId);
      if (!course) {
        return res.status(404).json({ message: "Course not found" });
      }
      
      // Check if already enrolled
      const existingEnrollment = await storage.getEnrollment(courseId, userId);
      if (existingEnrollment) {
        return res.status(400).json({ message: "Already enrolled in this course" });
      }
      
      const enrollment = await storage.createEnrollment({
        courseId,
        userId,
        progress: 0
      });
      
      res.status(201).json(enrollment);
    } catch (error) {
      res.status(500).json({ message: "Failed to enroll in course" });
    }
  });

  router.delete("/courses/:id/enroll", authenticateUser, async (req, res) => {
    try {
      const courseId = Number(req.params.id);
      const userId = req.user?.id;
      
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      // Find enrollment
      const enrollment = await storage.getEnrollment(courseId, userId);
      if (!enrollment) {
        return res.status(404).json({ message: "Enrollment not found" });
      }
      
      const success = await storage.deleteEnrollment(enrollment.id);
      
      if (!success) {
        return res.status(404).json({ message: "Enrollment not found" });
      }
      
      res.json({ message: "Unenrolled from course successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to unenroll from course" });
    }
  });

  // ===== Assignment Routes =====
  router.get("/courses/:id/assignments", authenticateUser, async (req, res) => {
    try {
      const courseId = Number(req.params.id);
      const userId = req.user?.id;
      
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      // Check if course exists
      const course = await storage.getCourse(courseId);
      if (!course) {
        return res.status(404).json({ message: "Course not found" });
      }
      
      // Check if user is enrolled or is the teacher
      const isTeacher = userId === course.teacherId;
      const enrollment = await storage.getEnrollment(courseId, userId);
      
      if (!isTeacher && !enrollment) {
        return res.status(403).json({ message: "Forbidden - You are not enrolled in this course" });
      }
      
      const assignments = await storage.getAssignmentsByCourse(courseId);
      
      // If student, add submission status to each assignment
      if (!isTeacher) {
        const assignmentsWithStatus = await Promise.all(assignments.map(async (assignment) => {
          const submission = await storage.getSubmissionByAssignmentAndUser(assignment.id, userId);
          
          let status = 'not_started';
          if (submission) {
            status = submission.status;
          } else if (new Date(assignment.dueDate) < new Date()) {
            status = 'overdue';
          }
          
          return {
            ...assignment,
            status,
            submission: submission || null
          };
        }));
        
        res.json(assignmentsWithStatus);
      } else {
        res.json(assignments);
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch assignments" });
    }
  });

  router.get("/assignments/:id", authenticateUser, async (req, res) => {
    try {
      const assignmentId = Number(req.params.id);
      const userId = req.user?.id;
      
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const assignment = await storage.getAssignment(assignmentId);
      
      if (!assignment) {
        return res.status(404).json({ message: "Assignment not found" });
      }
      
      // Get course
      const course = await storage.getCourse(assignment.courseId);
      if (!course) {
        return res.status(404).json({ message: "Course not found" });
      }
      
      // Check if user is enrolled or is the teacher
      const isTeacher = userId === course.teacherId;
      const enrollment = await storage.getEnrollment(course.id, userId);
      
      if (!isTeacher && !enrollment) {
        return res.status(403).json({ message: "Forbidden - You are not enrolled in this course" });
      }
      
      // If student, get submission
      const submission = !isTeacher ? 
        await storage.getSubmissionByAssignmentAndUser(assignmentId, userId) : 
        undefined;
      
      const assignmentWithDetails = {
        ...assignment,
        course: {
          id: course.id,
          name: course.name,
          color: course.color,
          icon: course.icon
        },
        submission: submission || null
      };
      
      res.json(assignmentWithDetails);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch assignment" });
    }
  });

  router.post("/courses/:id/assignments", authenticateUser, requireRole(['teacher', 'admin']), validateRequest(insertAssignmentSchema), async (req, res) => {
    try {
      const courseId = Number(req.params.id);
      
      // Check if course exists
      const course = await storage.getCourse(courseId);
      if (!course) {
        return res.status(404).json({ message: "Course not found" });
      }
      
      // Only teacher of the course or admin can add assignments
      if (req.user?.id !== course.teacherId && req.user?.role !== 'admin') {
        return res.status(403).json({ message: "Forbidden - You don't have permission to add assignments to this course" });
      }
      
      const assignment = await storage.createAssignment({
        ...req.body,
        courseId
      });
      
      res.status(201).json(assignment);
    } catch (error) {
      res.status(500).json({ message: "Failed to create assignment" });
    }
  });

  router.put("/assignments/:id", authenticateUser, requireRole(['teacher', 'admin']), async (req, res) => {
    try {
      const assignmentId = Number(req.params.id);
      const assignment = await storage.getAssignment(assignmentId);
      
      if (!assignment) {
        return res.status(404).json({ message: "Assignment not found" });
      }
      
      // Get course
      const course = await storage.getCourse(assignment.courseId);
      if (!course) {
        return res.status(404).json({ message: "Course not found" });
      }
      
      // Only teacher of the course or admin can update assignments
      if (req.user?.id !== course.teacherId && req.user?.role !== 'admin') {
        return res.status(403).json({ message: "Forbidden - You don't have permission to update this assignment" });
      }
      
      const updateSchema = z.object({
        title: z.string().optional(),
        description: z.string().optional().nullable(),
        dueDate: z.string().or(z.date()).optional(),
        points: z.number().optional()
      });
      
      const assignmentData = updateSchema.parse(req.body);
      const updatedAssignment = await storage.updateAssignment(assignmentId, assignmentData);
      
      if (!updatedAssignment) {
        return res.status(404).json({ message: "Assignment not found" });
      }
      
      res.json(updatedAssignment);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        res.status(400).json({ message: validationError.message });
      } else {
        res.status(500).json({ message: "Failed to update assignment" });
      }
    }
  });

  router.delete("/assignments/:id", authenticateUser, requireRole(['teacher', 'admin']), async (req, res) => {
    try {
      const assignmentId = Number(req.params.id);
      const assignment = await storage.getAssignment(assignmentId);
      
      if (!assignment) {
        return res.status(404).json({ message: "Assignment not found" });
      }
      
      // Get course
      const course = await storage.getCourse(assignment.courseId);
      if (!course) {
        return res.status(404).json({ message: "Course not found" });
      }
      
      // Only teacher of the course or admin can delete assignments
      if (req.user?.id !== course.teacherId && req.user?.role !== 'admin') {
        return res.status(403).json({ message: "Forbidden - You don't have permission to delete this assignment" });
      }
      
      const success = await storage.deleteAssignment(assignmentId);
      
      if (!success) {
        return res.status(404).json({ message: "Assignment not found" });
      }
      
      res.json({ message: "Assignment deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete assignment" });
    }
  });

  // ===== Submission Routes =====
  router.post("/assignments/:id/submit", authenticateUser, validateRequest(insertSubmissionSchema), async (req, res) => {
    try {
      const assignmentId = Number(req.params.id);
      const userId = req.user?.id;
      
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      // Check if assignment exists
      const assignment = await storage.getAssignment(assignmentId);
      if (!assignment) {
        return res.status(404).json({ message: "Assignment not found" });
      }
      
      // Check if user is enrolled in the course
      const enrollment = await storage.getEnrollment(assignment.courseId, userId);
      if (!enrollment) {
        return res.status(403).json({ message: "Forbidden - You are not enrolled in this course" });
      }
      
      // Check if already submitted
      const existingSubmission = await storage.getSubmissionByAssignmentAndUser(assignmentId, userId);
      
      if (existingSubmission) {
        // Update existing submission
        const updatedSubmission = await storage.updateSubmission(existingSubmission.id, {
          ...req.body,
          status: 'submitted'
        });
        
        return res.json(updatedSubmission);
      }
      
      // Create new submission
      const submission = await storage.createSubmission({
        ...req.body,
        assignmentId,
        userId,
        status: 'submitted'
      });
      
      res.status(201).json(submission);
    } catch (error) {
      res.status(500).json({ message: "Failed to submit assignment" });
    }
  });

  router.get("/assignments/:id/submissions", authenticateUser, requireRole(['teacher', 'admin']), async (req, res) => {
    try {
      const assignmentId = Number(req.params.id);
      
      // Check if assignment exists
      const assignment = await storage.getAssignment(assignmentId);
      if (!assignment) {
        return res.status(404).json({ message: "Assignment not found" });
      }
      
      // Get course
      const course = await storage.getCourse(assignment.courseId);
      if (!course) {
        return res.status(404).json({ message: "Course not found" });
      }
      
      // Only teacher of the course or admin can view all submissions
      if (req.user?.id !== course.teacherId && req.user?.role !== 'admin') {
        return res.status(403).json({ message: "Forbidden - You don't have permission to view these submissions" });
      }
      
      const submissions = await storage.getSubmissionsByAssignment(assignmentId);
      
      // Add user details to submissions
      const submissionsWithUsers = await Promise.all(submissions.map(async (submission) => {
        const user = await storage.getUser(submission.userId);
        return {
          ...submission,
          user: user ? {
            id: user.id,
            name: user.name,
            username: user.username,
            profileImage: user.profileImage
          } : null
        };
      }));
      
      res.json(submissionsWithUsers);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch submissions" });
    }
  });

  router.put("/submissions/:id/grade", authenticateUser, requireRole(['teacher', 'admin']), async (req, res) => {
    try {
      const submissionId = Number(req.params.id);
      const submission = await storage.getSubmission(submissionId);
      
      if (!submission) {
        return res.status(404).json({ message: "Submission not found" });
      }
      
      // Get assignment and course
      const assignment = await storage.getAssignment(submission.assignmentId);
      if (!assignment) {
        return res.status(404).json({ message: "Assignment not found" });
      }
      
      const course = await storage.getCourse(assignment.courseId);
      if (!course) {
        return res.status(404).json({ message: "Course not found" });
      }
      
      // Only teacher of the course or admin can grade submissions
      if (req.user?.id !== course.teacherId && req.user?.role !== 'admin') {
        return res.status(403).json({ message: "Forbidden - You don't have permission to grade this submission" });
      }
      
      const gradeSchema = z.object({
        grade: z.number().min(0).max(assignment.points),
        feedback: z.string().optional().nullable()
      });
      
      const gradeData = gradeSchema.parse(req.body);
      
      const updatedSubmission = await storage.updateSubmission(submissionId, {
        ...gradeData,
        status: 'graded'
      });
      
      if (!updatedSubmission) {
        return res.status(404).json({ message: "Submission not found" });
      }
      
      res.json(updatedSubmission);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        res.status(400).json({ message: validationError.message });
      } else {
        res.status(500).json({ message: "Failed to grade submission" });
      }
    }
  });

  // ===== Announcement Routes =====
  router.get("/announcements", authenticateUser, async (req, res) => {
    try {
      const userId = req.user?.id;
      if (!userId) return res.status(401).json({ message: "Unauthorized" });
      
      // Get global announcements
      const globalAnnouncements = await storage.getGlobalAnnouncements();
      
      // If student, get announcements for enrolled courses
      const user = await storage.getUser(userId);
      let courseAnnouncements: any[] = [];
      
      if (user?.role === 'student') {
        const enrolledCourses = await storage.getCoursesByStudent(userId);
        
        for (const course of enrolledCourses) {
          const announcements = await storage.getAnnouncementsByCourse(course.id);
          courseAnnouncements = [
            ...courseAnnouncements,
            ...announcements.map(a => ({ ...a, courseName: course.name }))
          ];
        }
      } else if (user?.role === 'teacher') {
        // If teacher, get announcements for courses they teach
        const teacherCourses = await storage.getCoursesByTeacher(userId);
        
        for (const course of teacherCourses) {
          const announcements = await storage.getAnnouncementsByCourse(course.id);
          courseAnnouncements = [
            ...courseAnnouncements,
            ...announcements.map(a => ({ ...a, courseName: course.name }))
          ];
        }
      }
      
      // Combine and sort by creation date (newest first)
      const allAnnouncements = [
        ...globalAnnouncements.map(a => ({ ...a, courseName: 'System Wide' })),
        ...courseAnnouncements
      ].sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
      
      // Add author details
      const announcementsWithAuthors = await Promise.all(allAnnouncements.map(async (announcement) => {
        const author = await storage.getUser(announcement.authorId);
        return {
          ...announcement,
          author: author ? {
            id: author.id,
            name: author.name,
            profileImage: author.profileImage
          } : null
        };
      }));
      
      res.json(announcementsWithAuthors);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch announcements" });
    }
  });

  router.post("/courses/:id/announcements", authenticateUser, requireRole(['teacher', 'admin']), validateRequest(insertAnnouncementSchema), async (req, res) => {
    try {
      const courseId = Number(req.params.id);
      const userId = req.user?.id;
      
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      // Check if course exists (if courseId is provided)
      if (courseId) {
        const course = await storage.getCourse(courseId);
        if (!course) {
          return res.status(404).json({ message: "Course not found" });
        }
        
        // Only teacher of the course or admin can create course announcements
        if (req.user?.id !== course.teacherId && req.user?.role !== 'admin') {
          return res.status(403).json({ message: "Forbidden - You don't have permission to create announcements for this course" });
        }
      }
      
      const announcement = await storage.createAnnouncement({
        ...req.body,
        authorId: userId,
        courseId: courseId || null
      });
      
      res.status(201).json(announcement);
    } catch (error) {
      res.status(500).json({ message: "Failed to create announcement" });
    }
  });

  router.post("/announcements", authenticateUser, requireRole(['teacher', 'admin']), validateRequest(insertAnnouncementSchema), async (req, res) => {
    try {
      const userId = req.user?.id;
      if (!userId) return res.status(401).json({ message: "Unauthorized" });
      
      // Create global announcement
      const announcement = await storage.createAnnouncement({
        ...req.body,
        authorId: userId,
        courseId: null
      });
      
      res.status(201).json(announcement);
    } catch (error) {
      res.status(500).json({ message: "Failed to create announcement" });
    }
  });

  router.delete("/announcements/:id", authenticateUser, async (req, res) => {
    try {
      const announcementId = Number(req.params.id);
      const announcement = await storage.getAnnouncement(announcementId);
      
      if (!announcement) {
        return res.status(404).json({ message: "Announcement not found" });
      }
      
      // Only author or admin can delete
      if (req.user?.id !== announcement.authorId && req.user?.role !== 'admin') {
        return res.status(403).json({ message: "Forbidden - You don't have permission to delete this announcement" });
      }
      
      const success = await storage.deleteAnnouncement(announcementId);
      
      if (!success) {
        return res.status(404).json({ message: "Announcement not found" });
      }
      
      res.json({ message: "Announcement deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete announcement" });
    }
  });

  // ===== Resource Routes =====
  router.get("/courses/:id/resources", authenticateUser, async (req, res) => {
    try {
      const courseId = Number(req.params.id);
      const userId = req.user?.id;
      
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      // Check if course exists
      const course = await storage.getCourse(courseId);
      if (!course) {
        return res.status(404).json({ message: "Course not found" });
      }
      
      // Check if user is enrolled or is the teacher
      const isTeacher = userId === course.teacherId;
      const enrollment = await storage.getEnrollment(courseId, userId);
      
      if (!isTeacher && !enrollment) {
        return res.status(403).json({ message: "Forbidden - You are not enrolled in this course" });
      }
      
      const resources = await storage.getResourcesByCourse(courseId);
      
      // Add creator details
      const resourcesWithCreators = await Promise.all(resources.map(async (resource) => {
        const creator = await storage.getUser(resource.createdBy);
        return {
          ...resource,
          creator: creator ? {
            id: creator.id,
            name: creator.name,
            profileImage: creator.profileImage
          } : null
        };
      }));
      
      res.json(resourcesWithCreators);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch resources" });
    }
  });

  router.post("/courses/:id/resources", authenticateUser, validateRequest(insertResourceSchema), async (req, res) => {
    try {
      const courseId = Number(req.params.id);
      const userId = req.user?.id;
      
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      // Check if course exists
      const course = await storage.getCourse(courseId);
      if (!course) {
        return res.status(404).json({ message: "Course not found" });
      }
      
      // Teacher can add resources, and students if allowed
      const isTeacher = userId === course.teacherId;
      const enrollment = await storage.getEnrollment(courseId, userId);
      
      if (!isTeacher && !enrollment) {
        return res.status(403).json({ message: "Forbidden - You are not enrolled in this course" });
      }
      
      const resource = await storage.createResource({
        ...req.body,
        courseId,
        createdBy: userId
      });
      
      res.status(201).json(resource);
    } catch (error) {
      res.status(500).json({ message: "Failed to create resource" });
    }
  });

  router.delete("/resources/:id", authenticateUser, async (req, res) => {
    try {
      const resourceId = Number(req.params.id);
      const resource = await storage.getResource(resourceId);
      
      if (!resource) {
        return res.status(404).json({ message: "Resource not found" });
      }
      
      // Only creator, teacher, or admin can delete
      const course = await storage.getCourse(resource.courseId);
      const isTeacher = course && req.user?.id === course.teacherId;
      const isCreator = req.user?.id === resource.createdBy;
      const isAdmin = req.user?.role === 'admin';
      
      if (!isCreator && !isTeacher && !isAdmin) {
        return res.status(403).json({ message: "Forbidden - You don't have permission to delete this resource" });
      }
      
      const success = await storage.deleteResource(resourceId);
      
      if (!success) {
        return res.status(404).json({ message: "Resource not found" });
      }
      
      res.json({ message: "Resource deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete resource" });
    }
  });

  // ===== Event/Schedule Routes =====
  router.get("/events", authenticateUser, async (req, res) => {
    try {
      const userId = req.user?.id;
      if (!userId) return res.status(401).json({ message: "Unauthorized" });
      
      const events = await storage.getEventsByUser(userId);
      
      // Add course and creator details
      const eventsWithDetails = await Promise.all(events.map(async (event) => {
        const course = event.courseId ? await storage.getCourse(event.courseId) : null;
        const creator = await storage.getUser(event.createdBy);
        
        return {
          ...event,
          course: course ? {
            id: course.id,
            name: course.name,
            color: course.color,
            icon: course.icon
          } : null,
          creator: creator ? {
            id: creator.id,
            name: creator.name,
            profileImage: creator.profileImage
          } : null
        };
      }));
      
      res.json(eventsWithDetails);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch events" });
    }
  });

  router.post("/courses/:id/events", authenticateUser, validateRequest(insertEventSchema), async (req, res) => {
    try {
      const courseId = Number(req.params.id);
      const userId = req.user?.id;
      
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      // Check if course exists
      const course = await storage.getCourse(courseId);
      if (!course) {
        return res.status(404).json({ message: "Course not found" });
      }
      
      // Only teacher of the course or admin can create course events
      if (req.user?.id !== course.teacherId && req.user?.role !== 'admin') {
        return res.status(403).json({ message: "Forbidden - You don't have permission to create events for this course" });
      }
      
      const event = await storage.createEvent({
        ...req.body,
        courseId,
        createdBy: userId
      });
      
      res.status(201).json(event);
    } catch (error) {
      res.status(500).json({ message: "Failed to create event" });
    }
  });

  router.post("/events", authenticateUser, validateRequest(insertEventSchema), async (req, res) => {
    try {
      const userId = req.user?.id;
      if (!userId) return res.status(401).json({ message: "Unauthorized" });
      
      // Create personal event
      const event = await storage.createEvent({
        ...req.body,
        courseId: null,
        createdBy: userId
      });
      
      res.status(201).json(event);
    } catch (error) {
      res.status(500).json({ message: "Failed to create event" });
    }
  });

  router.put("/events/:id", authenticateUser, async (req, res) => {
    try {
      const eventId = Number(req.params.id);
      const event = await storage.getEvent(eventId);
      
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }
      
      // Only creator or teacher of the course or admin can update
      const isCreator = req.user?.id === event.createdBy;
      const isTeacher = event.courseId ? 
        (await storage.getCourse(event.courseId))?.teacherId === req.user?.id : 
        false;
      const isAdmin = req.user?.role === 'admin';
      
      if (!isCreator && !isTeacher && !isAdmin) {
        return res.status(403).json({ message: "Forbidden - You don't have permission to update this event" });
      }
      
      const updateSchema = z.object({
        title: z.string().optional(),
        description: z.string().optional().nullable(),
        location: z.string().optional().nullable(),
        startTime: z.string().or(z.date()).optional(),
        endTime: z.string().or(z.date()).optional()
      });
      
      const eventData = updateSchema.parse(req.body);
      const updatedEvent = await storage.updateEvent(eventId, eventData);
      
      if (!updatedEvent) {
        return res.status(404).json({ message: "Event not found" });
      }
      
      res.json(updatedEvent);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        res.status(400).json({ message: validationError.message });
      } else {
        res.status(500).json({ message: "Failed to update event" });
      }
    }
  });

  router.delete("/events/:id", authenticateUser, async (req, res) => {
    try {
      const eventId = Number(req.params.id);
      const event = await storage.getEvent(eventId);
      
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }
      
      // Only creator or teacher of the course or admin can delete
      const isCreator = req.user?.id === event.createdBy;
      const isTeacher = event.courseId ? 
        (await storage.getCourse(event.courseId))?.teacherId === req.user?.id : 
        false;
      const isAdmin = req.user?.role === 'admin';
      
      if (!isCreator && !isTeacher && !isAdmin) {
        return res.status(403).json({ message: "Forbidden - You don't have permission to delete this event" });
      }
      
      const success = await storage.deleteEvent(eventId);
      
      if (!success) {
        return res.status(404).json({ message: "Event not found" });
      }
      
      res.json({ message: "Event deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete event" });
    }
  });

  // ===== Message Routes =====
  router.get("/messages", authenticateUser, async (req, res) => {
    try {
      const userId = req.user?.id;
      if (!userId) return res.status(401).json({ message: "Unauthorized" });
      
      const messages = await storage.getMessagesByUser(userId);
      
      // Group messages by conversation partner
      const conversations = new Map<number, {
        user: any,
        lastMessage: any,
        unreadCount: number
      }>();
      
      // Process each message
      for (const message of messages) {
        const partnerId = message.fromId === userId ? message.toId : message.fromId;
        
        // Skip if we've already processed this partner
        if (!conversations.has(partnerId)) {
          const partner = await storage.getUser(partnerId);
          
          if (partner) {
            conversations.set(partnerId, {
              user: {
                id: partner.id,
                name: partner.name,
                username: partner.username,
                profileImage: partner.profileImage
              },
              lastMessage: {
                id: message.id,
                content: message.content,
                createdAt: message.createdAt,
                isFromUser: message.fromId === userId
              },
              unreadCount: message.toId === userId && !message.isRead ? 1 : 0
            });
          }
        } else {
          // Update last message if this is newer
          const convo = conversations.get(partnerId)!;
          const lastMessageDate = new Date(convo.lastMessage.createdAt);
          
          if (message.createdAt > lastMessageDate) {
            convo.lastMessage = {
              id: message.id,
              content: message.content,
              createdAt: message.createdAt,
              isFromUser: message.fromId === userId
            };
          }
          
          // Increment unread count if applicable
          if (message.toId === userId && !message.isRead) {
            convo.unreadCount += 1;
          }
          
          conversations.set(partnerId, convo);
        }
      }
      
      // Convert to array and sort by most recent message
      const result = Array.from(conversations.values()).sort((a, b) => {
        return new Date(b.lastMessage.createdAt).getTime() - new Date(a.lastMessage.createdAt).getTime();
      });
      
      res.json(result);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  router.get("/messages/with/:userId", authenticateUser, async (req, res) => {
    try {
      const userId = req.user?.id;
      const partnerId = Number(req.params.userId);
      
      if (!userId) return res.status(401).json({ message: "Unauthorized" });
      
      // Check if partner exists
      const partner = await storage.getUser(partnerId);
      if (!partner) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const conversation = await storage.getConversation(userId, partnerId);
      
      // Mark messages as read
      const unreadMessagesToMe = conversation.filter(
        message => message.toId === userId && !message.isRead
      );
      
      for (const message of unreadMessagesToMe) {
        await storage.markMessageAsRead(message.id);
      }
      
      // Format messages for client
      const formattedMessages = conversation.map(message => ({
        id: message.id,
        content: message.content,
        createdAt: message.createdAt,
        fromMe: message.fromId === userId,
        isRead: message.isRead
      }));
      
      res.json({
        messages: formattedMessages,
        partner: {
          id: partner.id,
          name: partner.name,
          username: partner.username,
          profileImage: partner.profileImage
        }
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch conversation" });
    }
  });

  router.post("/messages", authenticateUser, validateRequest(insertMessageSchema), async (req, res) => {
    try {
      const userId = req.user?.id;
      if (!userId) return res.status(401).json({ message: "Unauthorized" });
      
      // Check if recipient exists
      const recipient = await storage.getUser(req.body.toId);
      if (!recipient) {
        return res.status(404).json({ message: "Recipient not found" });
      }
      
      const message = await storage.createMessage({
        ...req.body,
        fromId: userId
      });
      
      res.status(201).json(message);
    } catch (error) {
      res.status(500).json({ message: "Failed to send message" });
    }
  });

  // Register API routes
  app.use("/api", router);

  const httpServer = createServer(app);

  return httpServer;
}
