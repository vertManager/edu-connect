import {
  users, courses, enrollments, assignments, submissions, announcements, resources, events, messages,
  type User, type InsertUser, type Course, type InsertCourse, type Enrollment, type InsertEnrollment,
  type Assignment, type InsertAssignment, type Submission, type InsertSubmission,
  type Announcement, type InsertAnnouncement, type Resource, type InsertResource,
  type Event, type InsertEvent, type Message, type InsertMessage
} from "@shared/schema";

// Storage interface with all CRUD operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User | undefined>;

  // Course operations
  getCourse(id: number): Promise<Course | undefined>;
  getCourses(): Promise<Course[]>;
  getCoursesByTeacher(teacherId: number): Promise<Course[]>;
  getCoursesByStudent(studentId: number): Promise<(Course & { progress: number })[]>;
  createCourse(course: InsertCourse): Promise<Course>;
  updateCourse(id: number, course: Partial<Course>): Promise<Course | undefined>;
  deleteCourse(id: number): Promise<boolean>;

  // Enrollment operations
  getEnrollment(courseId: number, userId: number): Promise<Enrollment | undefined>;
  getEnrollments(courseId: number): Promise<Enrollment[]>;
  createEnrollment(enrollment: InsertEnrollment): Promise<Enrollment>;
  updateEnrollment(id: number, enrollment: Partial<Enrollment>): Promise<Enrollment | undefined>;
  deleteEnrollment(id: number): Promise<boolean>;

  // Assignment operations
  getAssignment(id: number): Promise<Assignment | undefined>;
  getAssignmentsByCourse(courseId: number): Promise<Assignment[]>;
  getAssignmentsByStudent(studentId: number): Promise<(Assignment & { status?: string })[]>;
  createAssignment(assignment: InsertAssignment): Promise<Assignment>;
  updateAssignment(id: number, assignment: Partial<Assignment>): Promise<Assignment | undefined>;
  deleteAssignment(id: number): Promise<boolean>;

  // Submission operations
  getSubmission(id: number): Promise<Submission | undefined>;
  getSubmissionByAssignmentAndUser(assignmentId: number, userId: number): Promise<Submission | undefined>;
  getSubmissionsByAssignment(assignmentId: number): Promise<Submission[]>;
  getSubmissionsByUser(userId: number): Promise<Submission[]>;
  createSubmission(submission: InsertSubmission): Promise<Submission>;
  updateSubmission(id: number, submission: Partial<Submission>): Promise<Submission | undefined>;

  // Announcement operations
  getAnnouncement(id: number): Promise<Announcement | undefined>;
  getAnnouncementsByCourse(courseId: number): Promise<Announcement[]>;
  getGlobalAnnouncements(): Promise<Announcement[]>;
  createAnnouncement(announcement: InsertAnnouncement): Promise<Announcement>;
  deleteAnnouncement(id: number): Promise<boolean>;

  // Resource operations
  getResource(id: number): Promise<Resource | undefined>;
  getResourcesByCourse(courseId: number): Promise<Resource[]>;
  createResource(resource: InsertResource): Promise<Resource>;
  deleteResource(id: number): Promise<boolean>;

  // Event operations
  getEvent(id: number): Promise<Event | undefined>;
  getEventsByCourse(courseId: number): Promise<Event[]>;
  getEventsByUser(userId: number): Promise<Event[]>;
  createEvent(event: InsertEvent): Promise<Event>;
  updateEvent(id: number, event: Partial<Event>): Promise<Event | undefined>;
  deleteEvent(id: number): Promise<boolean>;

  // Message operations
  getMessage(id: number): Promise<Message | undefined>;
  getMessagesByUser(userId: number): Promise<Message[]>;
  getConversation(user1Id: number, user2Id: number): Promise<Message[]>;
  getUnreadMessageCount(userId: number): Promise<number>;
  createMessage(message: InsertMessage): Promise<Message>;
  markMessageAsRead(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private courses: Map<number, Course>;
  private enrollments: Map<number, Enrollment>;
  private assignments: Map<number, Assignment>;
  private submissions: Map<number, Submission>;
  private announcements: Map<number, Announcement>;
  private resources: Map<number, Resource>;
  private events: Map<number, Event>;
  private messages: Map<number, Message>;
  
  private userIdCounter: number;
  private courseIdCounter: number;
  private enrollmentIdCounter: number;
  private assignmentIdCounter: number;
  private submissionIdCounter: number;
  private announcementIdCounter: number;
  private resourceIdCounter: number;
  private eventIdCounter: number;
  private messageIdCounter: number;

  constructor() {
    this.users = new Map();
    this.courses = new Map();
    this.enrollments = new Map();
    this.assignments = new Map();
    this.submissions = new Map();
    this.announcements = new Map();
    this.resources = new Map();
    this.events = new Map();
    this.messages = new Map();
    
    this.userIdCounter = 1;
    this.courseIdCounter = 1;
    this.enrollmentIdCounter = 1;
    this.assignmentIdCounter = 1;
    this.submissionIdCounter = 1;
    this.announcementIdCounter = 1;
    this.resourceIdCounter = 1;
    this.eventIdCounter = 1;
    this.messageIdCounter = 1;

    // Add some initial test data
    this.seedData();
  }

  private seedData(): void {
    // Add demo users (teacher & student)
    const teacher = this.createUser({
      username: 'teacher',
      password: 'password',
      name: 'Sarah Miller',
      email: 'teacher@educonnect.com',
      role: 'teacher',
      profileImage: undefined
    });

    const student = this.createUser({
      username: 'student',
      password: 'password',
      name: 'Alex Johnson',
      email: 'student@educonnect.com',
      role: 'student',
      profileImage: undefined
    });

    // Add demo courses
    const biology = this.createCourse({
      name: 'Biology 101',
      description: 'Introduction to biology concepts and principles',
      teacherId: teacher.id,
      color: '#4166B0',
      icon: 'ri-microscope-line'
    });

    const computerScience = this.createCourse({
      name: 'Computer Science',
      description: 'Introduction to programming and computer science concepts',
      teacherId: teacher.id,
      color: '#45A29E',
      icon: 'ri-code-s-slash-line'
    });

    const english = this.createCourse({
      name: 'English Literature',
      description: 'Survey of major literary works and critical analysis',
      teacherId: teacher.id,
      color: '#FF7F50',
      icon: 'ri-book-2-line'
    });

    const math = this.createCourse({
      name: 'Mathematics',
      description: 'Mathematical concepts and problem solving',
      teacherId: teacher.id,
      color: '#2ECC71',
      icon: 'ri-number-5'
    });

    // Enroll student in courses
    this.createEnrollment({
      courseId: biology.id,
      userId: student.id,
      progress: 75
    });

    this.createEnrollment({
      courseId: computerScience.id,
      userId: student.id,
      progress: 60
    });

    this.createEnrollment({
      courseId: english.id,
      userId: student.id,
      progress: 90
    });

    this.createEnrollment({
      courseId: math.id,
      userId: student.id,
      progress: 45
    });

    // Create assignments
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    const today = new Date();
    
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    
    const nextWeek = new Date();
    nextWeek.setDate(nextWeek.getDate() + 7);

    this.createAssignment({
      title: 'Lab Report #3',
      description: 'Complete the lab report for the photosynthesis experiment',
      courseId: biology.id,
      dueDate: tomorrow,
      points: 15
    });

    this.createAssignment({
      title: 'Programming Project',
      description: 'Create a simple web application using HTML, CSS, and JavaScript',
      courseId: computerScience.id,
      dueDate: today,
      points: 40
    });

    this.createAssignment({
      title: 'Essay Draft',
      description: 'Submit a draft of your literary analysis essay',
      courseId: english.id,
      dueDate: nextWeek,
      points: 25
    });

    this.createAssignment({
      title: 'Problem Set #4',
      description: 'Complete problems 1-15 on page 127',
      courseId: math.id,
      dueDate: yesterday,
      points: 20
    });

    // Add some submissions
    this.createSubmission({
      assignmentId: 3,
      userId: student.id,
      status: 'completed',
      content: 'My essay draft submission',
      grade: null,
      feedback: null,
      submittedAt: null
    });

    // Add announcements
    const twoDaysAgo = new Date();
    twoDaysAgo.setDate(twoDaysAgo.getDate() - 2);
    
    this.createAnnouncement({
      title: 'Campus System Maintenance',
      content: 'The system will be down for maintenance this Saturday from 2-4 AM. Plan accordingly.',
      authorId: teacher.id,
      courseId: null
    });

    this.createAnnouncement({
      title: 'Biology Midterm Rescheduled',
      content: 'The Biology 101 midterm has been moved to next Wednesday. Review sessions available Monday.',
      authorId: teacher.id,
      courseId: biology.id
    });

    this.createAnnouncement({
      title: 'Library Extended Hours',
      content: 'The library will have extended hours during finals week, open 24/7 from Dec 10-17.',
      authorId: teacher.id,
      courseId: null
    });

    // Add schedule events
    const today9am = new Date();
    today9am.setHours(9, 0, 0, 0);
    
    const today1030am = new Date();
    today1030am.setHours(10, 30, 0, 0);
    
    const today2pm = new Date();
    today2pm.setHours(14, 0, 0, 0);
    
    const today330pm = new Date();
    today330pm.setHours(15, 30, 0, 0);
    
    const today4pm = new Date();
    today4pm.setHours(16, 0, 0, 0);
    
    const today530pm = new Date();
    today530pm.setHours(17, 30, 0, 0);
    
    const tomorrow1030am = new Date(today1030am);
    tomorrow1030am.setDate(tomorrow1030am.getDate() + 1);
    
    const tomorrow12pm = new Date();
    tomorrow12pm.setHours(12, 0, 0, 0);
    tomorrow12pm.setDate(tomorrow12pm.getDate() + 1);

    this.createEvent({
      title: 'Biology 101',
      description: 'Regular class session',
      courseId: biology.id,
      startTime: today9am,
      endTime: today1030am,
      location: 'Room 302, Science Building',
      createdBy: teacher.id
    });

    this.createEvent({
      title: 'Computer Science',
      description: 'Regular class session',
      courseId: computerScience.id,
      startTime: today2pm,
      endTime: today330pm,
      location: 'Room 105, Tech Center',
      createdBy: teacher.id
    });

    this.createEvent({
      title: 'Study Group: Biology',
      description: 'Group study session for upcoming exam',
      courseId: biology.id,
      startTime: today4pm,
      endTime: today530pm,
      location: 'Library, Study Room #3',
      createdBy: student.id
    });

    this.createEvent({
      title: 'English Literature',
      description: 'Regular class session',
      courseId: english.id,
      startTime: tomorrow1030am,
      endTime: tomorrow12pm,
      location: 'Room 210, Arts Building',
      createdBy: teacher.id
    });

    // Add messages
    this.createMessage({
      content: 'Hello! Do you have a question about the upcoming assignment?',
      fromId: teacher.id,
      toId: student.id
    });

    this.createMessage({
      content: 'Yes, I was wondering if we could use external sources for the essay?',
      fromId: student.id,
      toId: teacher.id
    });

    this.createMessage({
      content: 'Absolutely, just make sure to cite them properly using MLA format.',
      fromId: teacher.id,
      toId: student.id
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(user: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const newUser: User = { ...user, id };
    this.users.set(id, newUser);
    return newUser;
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const user = await this.getUser(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Course operations
  async getCourse(id: number): Promise<Course | undefined> {
    return this.courses.get(id);
  }

  async getCourses(): Promise<Course[]> {
    return Array.from(this.courses.values());
  }

  async getCoursesByTeacher(teacherId: number): Promise<Course[]> {
    return Array.from(this.courses.values()).filter(
      (course) => course.teacherId === teacherId
    );
  }

  async getCoursesByStudent(studentId: number): Promise<(Course & { progress: number })[]> {
    const userEnrollments = Array.from(this.enrollments.values()).filter(
      (enrollment) => enrollment.userId === studentId
    );
    
    return userEnrollments.map(enrollment => {
      const course = this.courses.get(enrollment.courseId);
      if (!course) throw new Error(`Course with id ${enrollment.courseId} not found`);
      return {
        ...course,
        progress: enrollment.progress || 0
      };
    });
  }

  async createCourse(course: InsertCourse): Promise<Course> {
    const id = this.courseIdCounter++;
    const newCourse: Course = { ...course, id };
    this.courses.set(id, newCourse);
    return newCourse;
  }

  async updateCourse(id: number, courseData: Partial<Course>): Promise<Course | undefined> {
    const course = await this.getCourse(id);
    if (!course) return undefined;
    
    const updatedCourse = { ...course, ...courseData };
    this.courses.set(id, updatedCourse);
    return updatedCourse;
  }

  async deleteCourse(id: number): Promise<boolean> {
    return this.courses.delete(id);
  }

  // Enrollment operations
  async getEnrollment(courseId: number, userId: number): Promise<Enrollment | undefined> {
    return Array.from(this.enrollments.values()).find(
      (enrollment) => enrollment.courseId === courseId && enrollment.userId === userId
    );
  }

  async getEnrollments(courseId: number): Promise<Enrollment[]> {
    return Array.from(this.enrollments.values()).filter(
      (enrollment) => enrollment.courseId === courseId
    );
  }

  async createEnrollment(enrollment: InsertEnrollment): Promise<Enrollment> {
    const id = this.enrollmentIdCounter++;
    const now = new Date();
    const newEnrollment: Enrollment = { 
      ...enrollment, 
      id, 
      enrolledAt: now 
    };
    this.enrollments.set(id, newEnrollment);
    return newEnrollment;
  }

  async updateEnrollment(id: number, enrollmentData: Partial<Enrollment>): Promise<Enrollment | undefined> {
    const enrollment = this.enrollments.get(id);
    if (!enrollment) return undefined;
    
    const updatedEnrollment = { ...enrollment, ...enrollmentData };
    this.enrollments.set(id, updatedEnrollment);
    return updatedEnrollment;
  }

  async deleteEnrollment(id: number): Promise<boolean> {
    return this.enrollments.delete(id);
  }

  // Assignment operations
  async getAssignment(id: number): Promise<Assignment | undefined> {
    return this.assignments.get(id);
  }

  async getAssignmentsByCourse(courseId: number): Promise<Assignment[]> {
    return Array.from(this.assignments.values()).filter(
      (assignment) => assignment.courseId === courseId
    );
  }

  async getAssignmentsByStudent(studentId: number): Promise<(Assignment & { status?: string })[]> {
    // Get all courses the student is enrolled in
    const enrolledCourses = await this.getCoursesByStudent(studentId);
    const courseIds = enrolledCourses.map(course => course.id);
    
    // Get all assignments for those courses
    const studentAssignments = Array.from(this.assignments.values()).filter(
      (assignment) => courseIds.includes(assignment.courseId)
    );
    
    // Add submission status to each assignment
    return await Promise.all(studentAssignments.map(async (assignment) => {
      const submission = await this.getSubmissionByAssignmentAndUser(assignment.id, studentId);
      
      // Determine status based on submission and due date
      let status = 'not_started';
      if (submission) {
        status = submission.status;
      } else if (new Date(assignment.dueDate) < new Date()) {
        status = 'overdue';
      }
      
      return {
        ...assignment,
        status
      };
    }));
  }

  async createAssignment(assignment: InsertAssignment): Promise<Assignment> {
    const id = this.assignmentIdCounter++;
    const now = new Date();
    const newAssignment: Assignment = { 
      ...assignment, 
      id, 
      createdAt: now 
    };
    this.assignments.set(id, newAssignment);
    return newAssignment;
  }

  async updateAssignment(id: number, assignmentData: Partial<Assignment>): Promise<Assignment | undefined> {
    const assignment = await this.getAssignment(id);
    if (!assignment) return undefined;
    
    const updatedAssignment = { ...assignment, ...assignmentData };
    this.assignments.set(id, updatedAssignment);
    return updatedAssignment;
  }

  async deleteAssignment(id: number): Promise<boolean> {
    return this.assignments.delete(id);
  }

  // Submission operations
  async getSubmission(id: number): Promise<Submission | undefined> {
    return this.submissions.get(id);
  }

  async getSubmissionByAssignmentAndUser(assignmentId: number, userId: number): Promise<Submission | undefined> {
    return Array.from(this.submissions.values()).find(
      (submission) => submission.assignmentId === assignmentId && submission.userId === userId
    );
  }

  async getSubmissionsByAssignment(assignmentId: number): Promise<Submission[]> {
    return Array.from(this.submissions.values()).filter(
      (submission) => submission.assignmentId === assignmentId
    );
  }

  async getSubmissionsByUser(userId: number): Promise<Submission[]> {
    return Array.from(this.submissions.values()).filter(
      (submission) => submission.userId === userId
    );
  }

  async createSubmission(submission: InsertSubmission): Promise<Submission> {
    const id = this.submissionIdCounter++;
    const now = new Date();
    const newSubmission: Submission = { 
      ...submission, 
      id,
      submittedAt: submission.status === 'submitted' ? now : null
    };
    this.submissions.set(id, newSubmission);
    return newSubmission;
  }

  async updateSubmission(id: number, submissionData: Partial<Submission>): Promise<Submission | undefined> {
    const submission = await this.getSubmission(id);
    if (!submission) return undefined;
    
    // If status is changing to submitted, update submittedAt
    let updatedData = { ...submissionData };
    if (submissionData.status === 'submitted' && submission.status !== 'submitted') {
      updatedData.submittedAt = new Date();
    }
    
    const updatedSubmission = { ...submission, ...updatedData };
    this.submissions.set(id, updatedSubmission);
    return updatedSubmission;
  }

  // Announcement operations
  async getAnnouncement(id: number): Promise<Announcement | undefined> {
    return this.announcements.get(id);
  }

  async getAnnouncementsByCourse(courseId: number): Promise<Announcement[]> {
    return Array.from(this.announcements.values()).filter(
      (announcement) => announcement.courseId === courseId
    );
  }

  async getGlobalAnnouncements(): Promise<Announcement[]> {
    return Array.from(this.announcements.values()).filter(
      (announcement) => announcement.courseId === null
    );
  }

  async createAnnouncement(announcement: InsertAnnouncement): Promise<Announcement> {
    const id = this.announcementIdCounter++;
    const now = new Date();
    const newAnnouncement: Announcement = { 
      ...announcement, 
      id, 
      createdAt: now 
    };
    this.announcements.set(id, newAnnouncement);
    return newAnnouncement;
  }

  async deleteAnnouncement(id: number): Promise<boolean> {
    return this.announcements.delete(id);
  }

  // Resource operations
  async getResource(id: number): Promise<Resource | undefined> {
    return this.resources.get(id);
  }

  async getResourcesByCourse(courseId: number): Promise<Resource[]> {
    return Array.from(this.resources.values()).filter(
      (resource) => resource.courseId === courseId
    );
  }

  async createResource(resource: InsertResource): Promise<Resource> {
    const id = this.resourceIdCounter++;
    const now = new Date();
    const newResource: Resource = { 
      ...resource, 
      id, 
      createdAt: now 
    };
    this.resources.set(id, newResource);
    return newResource;
  }

  async deleteResource(id: number): Promise<boolean> {
    return this.resources.delete(id);
  }

  // Event operations
  async getEvent(id: number): Promise<Event | undefined> {
    return this.events.get(id);
  }

  async getEventsByCourse(courseId: number): Promise<Event[]> {
    return Array.from(this.events.values()).filter(
      (event) => event.courseId === courseId
    );
  }

  async getEventsByUser(userId: number): Promise<Event[]> {
    // Get courses the user is enrolled in
    const enrolledCourses = await this.getCoursesByStudent(userId);
    const courseIds = enrolledCourses.map(course => course.id);
    
    // Get teacher's courses if user is a teacher
    const user = await this.getUser(userId);
    if (user?.role === 'teacher') {
      const teacherCourses = await this.getCoursesByTeacher(userId);
      teacherCourses.forEach(course => {
        if (!courseIds.includes(course.id)) {
          courseIds.push(course.id);
        }
      });
    }
    
    // Get events for these courses
    return Array.from(this.events.values()).filter(
      (event) => event.courseId === null || courseIds.includes(event.courseId)
    );
  }

  async createEvent(event: InsertEvent): Promise<Event> {
    const id = this.eventIdCounter++;
    const newEvent: Event = { ...event, id };
    this.events.set(id, newEvent);
    return newEvent;
  }

  async updateEvent(id: number, eventData: Partial<Event>): Promise<Event | undefined> {
    const event = await this.getEvent(id);
    if (!event) return undefined;
    
    const updatedEvent = { ...event, ...eventData };
    this.events.set(id, updatedEvent);
    return updatedEvent;
  }

  async deleteEvent(id: number): Promise<boolean> {
    return this.events.delete(id);
  }

  // Message operations
  async getMessage(id: number): Promise<Message | undefined> {
    return this.messages.get(id);
  }

  async getMessagesByUser(userId: number): Promise<Message[]> {
    return Array.from(this.messages.values()).filter(
      (message) => message.toId === userId || message.fromId === userId
    );
  }

  async getConversation(user1Id: number, user2Id: number): Promise<Message[]> {
    return Array.from(this.messages.values()).filter(
      (message) => 
        (message.fromId === user1Id && message.toId === user2Id) ||
        (message.fromId === user2Id && message.toId === user1Id)
    ).sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());
  }

  async getUnreadMessageCount(userId: number): Promise<number> {
    return Array.from(this.messages.values()).filter(
      (message) => message.toId === userId && !message.isRead
    ).length;
  }

  async createMessage(message: InsertMessage): Promise<Message> {
    const id = this.messageIdCounter++;
    const now = new Date();
    const newMessage: Message = { 
      ...message, 
      id, 
      createdAt: now,
      isRead: false
    };
    this.messages.set(id, newMessage);
    return newMessage;
  }

  async markMessageAsRead(id: number): Promise<boolean> {
    const message = await this.getMessage(id);
    if (!message) return false;
    
    message.isRead = true;
    this.messages.set(id, message);
    return true;
  }
}

export const storage = new MemStorage();
