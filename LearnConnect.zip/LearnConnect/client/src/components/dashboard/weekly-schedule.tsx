import { useMemo } from 'react';
import { format, startOfToday, addDays, isToday, isTomorrow, isThisWeek } from 'date-fns';

interface Event {
  id: number;
  title: string;
  description?: string;
  startTime: string | Date;
  endTime: string | Date;
  location?: string;
  course?: {
    id: number;
    name: string;
    color: string;
  };
}

interface FormattedEvent {
  id: number;
  title: string;
  description?: string;
  startTime: Date;
  endTime: Date;
  location?: string;
  course?: {
    id: number;
    name: string;
    color: string;
  };
  // Calculated fields
  startTimeFormatted: string;
  endTimeFormatted: string;
  isToday: boolean;
  colorClass: string;
}

export default function WeeklySchedule({ events }: { events: Event[] }) {
  // Create array for days of the week
  const today = startOfToday();
  const weekdays = Array.from({ length: 7 }).map((_, i) => {
    const date = addDays(today, i);
    return {
      date,
      day: format(date, 'EEE'),
      dayNum: format(date, 'd'),
      isToday: isToday(date),
    };
  });

  // Format and filter events for this week
  const formattedEvents: FormattedEvent[] = useMemo(() => {
    return events
      .filter(event => {
        const eventDate = new Date(event.startTime);
        return isThisWeek(eventDate, { weekStartsOn: 1 });
      })
      .map(event => {
        const startTime = new Date(event.startTime);
        const endTime = new Date(event.endTime);

        // Determine color class based on course
        let colorClass = 'bg-neutral-50 dark:bg-neutral-800/50 border-neutral-400';
        if (event.course?.color) {
          const color = event.course.color.replace('#', '');
          colorClass = `bg-${color}-50 dark:bg-${color}-900/20 border-${color}-500`;
        } else if (event.title.toLowerCase().includes('biology')) {
          colorClass = 'bg-primary-50 dark:bg-primary-900/20 border-primary-500';
        } else if (event.title.toLowerCase().includes('computer')) {
          colorClass = 'bg-secondary-50 dark:bg-secondary-900/20 border-secondary-500';
        } else if (event.title.toLowerCase().includes('english')) {
          colorClass = 'bg-accent-50 dark:bg-accent-900/20 border-accent-500';
        }

        return {
          ...event,
          startTime,
          endTime,
          startTimeFormatted: format(startTime, 'h:mm a'),
          endTimeFormatted: format(endTime, 'h:mm a'),
          isToday: isToday(startTime),
          colorClass,
        };
      })
      .sort((a, b) => a.startTime.getTime() - b.startTime.getTime());
  }, [events]);

  return (
    <div>
      <div className="grid grid-cols-7 gap-1 mb-2">
        {weekdays.map((day) => (
          <div 
            key={day.day} 
            className={`text-center ${day.isToday 
              ? 'bg-primary-50 dark:bg-primary-900/20 rounded-lg' 
              : ''}`}
          >
            <div className={`text-sm ${day.isToday 
              ? 'text-primary-600 dark:text-primary-400' 
              : 'text-neutral-500 dark:text-neutral-400'}`}
            >
              {day.day}
            </div>
            <div className={`text-lg font-medium mt-1 ${day.isToday 
              ? 'text-primary-600 dark:text-primary-400' 
              : ''}`}
            >
              {day.dayNum}
            </div>
          </div>
        ))}
      </div>
      
      <div className="mt-4 space-y-3">
        {formattedEvents.length > 0 ? (
          formattedEvents.map((event) => (
            <div 
              key={event.id} 
              className={`flex items-center p-2 rounded-md ${event.colorClass} border-l-4`}
            >
              <div className="w-16 text-center mr-4">
                <div className="text-sm font-medium">{event.startTimeFormatted}</div>
                <div className="text-xs text-neutral-500 dark:text-neutral-400">{event.endTimeFormatted}</div>
              </div>
              <div className="flex-1">
                <h4 className="font-medium">{event.title}</h4>
                <p className="text-sm text-neutral-600 dark:text-neutral-400">{event.location}</p>
              </div>
              <div>
                {event.isToday ? (
                  <span className="px-2 py-1 text-xs rounded-full bg-primary-100 dark:bg-primary-900/50 text-primary-600 dark:text-primary-400">
                    Today
                  </span>
                ) : isTomorrow(event.startTime) ? (
                  <span className="px-2 py-1 text-xs rounded-full bg-neutral-200 dark:bg-neutral-700 text-neutral-700 dark:text-neutral-300">
                    Tomorrow
                  </span>
                ) : (
                  <span className="px-2 py-1 text-xs rounded-full bg-neutral-200 dark:bg-neutral-700 text-neutral-700 dark:text-neutral-300">
                    {format(event.startTime, 'EEE')}
                  </span>
                )}
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-8 text-neutral-500 dark:text-neutral-400">
            <p>No events scheduled for this week</p>
          </div>
        )}
      </div>
    </div>
  );
}
