import { Progress } from "@/components/ui/progress";
import { Link } from "wouter";

export interface CourseCardProps {
  id: number;
  name: string;
  teacherName: string;
  color: string;
  icon: string;
  nextClass?: {
    date: string;
    time: string;
  };
  progress: number;
  assignments: {
    count: number;
    status?: 'overdue' | 'pending' | 'none';
  };
}

export default function CourseCard({
  id,
  name,
  teacherName,
  color,
  icon,
  nextClass,
  progress,
  assignments
}: CourseCardProps) {
  // Generate gradient based on course color
  const gradient = `bg-gradient-to-r from-${color.replace('#', '')}-400 to-${color.replace('#', '')}-600`;
  
  // Default styles for non-Tailwind gradients
  const defaultStyle = {
    backgroundImage: `linear-gradient(to right, ${color}99, ${color})`,
  };

  // Assignment status display
  const getAssignmentStatus = () => {
    if (assignments.count === 0) {
      return (
        <span className="text-xs px-2 py-1 rounded-full bg-neutral-200 dark:bg-neutral-700 text-neutral-700 dark:text-neutral-300">
          No assignments
        </span>
      );
    }
    
    if (assignments.status === 'overdue') {
      return (
        <span className="text-xs px-2 py-1 rounded-full bg-error-100 dark:bg-error-900/30 text-error-600 dark:text-error-400">
          {assignments.count} Overdue
        </span>
      );
    }
    
    if (assignments.status === 'pending') {
      return (
        <span className="text-xs px-2 py-1 rounded-full bg-warning-100 dark:bg-warning-900/30 text-warning-600 dark:text-warning-400">
          {assignments.count} Pending
        </span>
      );
    }
    
    return (
      <span className="text-xs px-2 py-1 rounded-full bg-primary-100 dark:bg-primary-900/30 text-primary-600 dark:text-primary-400">
        {assignments.count} Assignments
      </span>
    );
  };

  return (
    <Link href={`/courses/${id}`}>
      <div className="relative group rounded-lg border border-neutral-200 dark:border-neutral-800 overflow-hidden transition-all hover:shadow-md cursor-pointer">
        <div className="h-28 relative" style={defaultStyle}>
          <div className="absolute inset-0 bg-black bg-opacity-20"></div>
          <div className="absolute bottom-3 left-3 text-white">
            <h3 className="font-semibold text-lg">{name}</h3>
            <p className="text-sm opacity-90">Prof. {teacherName}</p>
          </div>
          <div className="absolute top-3 right-3 bg-white dark:bg-neutral-900 text-primary-500 w-8 h-8 rounded-full flex items-center justify-center shadow-sm">
            <i className={icon}></i>
          </div>
        </div>
        <div className="p-3">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm text-neutral-600 dark:text-neutral-400">
              Next class: <span className="font-medium">
                {nextClass ? `${nextClass.date}, ${nextClass.time}` : 'No upcoming classes'}
              </span>
            </span>
            {getAssignmentStatus()}
          </div>
          <Progress value={progress} className="h-1.5 mb-1" />
          <p className="text-xs text-neutral-500 dark:text-neutral-400">{progress}% complete</p>
        </div>
      </div>
    </Link>
  );
}
