import { Link } from "wouter";

export interface QuickActionCardProps {
  icon: string;
  iconColor: string;
  title: string;
  value: string;
  linkTo: string;
  bgColorClass?: string;
}

export default function QuickActionCard({
  icon,
  iconColor,
  title,
  value,
  linkTo,
  bgColorClass = "bg-primary-100 dark:bg-primary-900/50"
}: QuickActionCardProps) {
  return (
    <Link href={linkTo}>
      <div className="bg-white dark:bg-neutral-900 rounded-lg shadow-sm hover:shadow-md transition-shadow p-4 flex items-center space-x-3 border border-neutral-200 dark:border-neutral-800 cursor-pointer">
        <div className={`flex-shrink-0 h-10 w-10 rounded-full ${bgColorClass} flex items-center justify-center text-${iconColor}-500`}>
          <i className={`${icon} text-xl`}></i>
        </div>
        <div>
          <h3 className="font-medium">{title}</h3>
          <p className="text-sm text-neutral-500 dark:text-neutral-400">{value}</p>
        </div>
      </div>
    </Link>
  );
}
