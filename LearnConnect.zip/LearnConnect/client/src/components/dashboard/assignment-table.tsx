import { format } from "date-fns";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export interface AssignmentProps {
  id: number;
  title: string;
  courseId: number;
  courseName: string;
  points: number;
  dueDate: Date;
  status: 'not_started' | 'in_progress' | 'completed' | 'submitted' | 'graded' | 'overdue';
  icon: string;
  iconColor: string;
}

export default function AssignmentTable({ assignments }: { assignments: AssignmentProps[] }) {
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'not_started':
        return (
          <span className="px-2 py-1 text-xs rounded-full bg-warning-100 dark:bg-warning-900/30 text-warning-800 dark:text-warning-200">
            Not Started
          </span>
        );
      case 'in_progress':
        return (
          <span className="px-2 py-1 text-xs rounded-full bg-primary-100 dark:bg-primary-900/30 text-primary-800 dark:text-primary-200">
            In Progress
          </span>
        );
      case 'completed':
        return (
          <span className="px-2 py-1 text-xs rounded-full bg-success-100 dark:bg-success-900/30 text-success-800 dark:text-success-200">
            Completed
          </span>
        );
      case 'submitted':
        return (
          <span className="px-2 py-1 text-xs rounded-full bg-success-100 dark:bg-success-900/30 text-success-800 dark:text-success-200">
            Submitted
          </span>
        );
      case 'graded':
        return (
          <span className="px-2 py-1 text-xs rounded-full bg-primary-100 dark:bg-primary-900/30 text-primary-800 dark:text-primary-200">
            Graded
          </span>
        );
      case 'overdue':
        return (
          <span className="px-2 py-1 text-xs rounded-full bg-error-100 dark:bg-error-900/30 text-error-800 dark:text-error-200">
            Overdue
          </span>
        );
      default:
        return null;
    }
  };

  const getActionButton = (status: string, id: number) => {
    switch (status) {
      case 'not_started':
        return (
          <Button variant="link" asChild>
            <Link href={`/assignments/${id}`}>Start</Link>
          </Button>
        );
      case 'in_progress':
        return (
          <Button variant="link" asChild>
            <Link href={`/assignments/${id}`}>Continue</Link>
          </Button>
        );
      case 'completed':
      case 'submitted':
      case 'graded':
        return (
          <Button variant="link" asChild>
            <Link href={`/assignments/${id}`}>View</Link>
          </Button>
        );
      case 'overdue':
        return (
          <Button variant="link" asChild>
            <Link href={`/assignments/${id}`}>Submit Late</Link>
          </Button>
        );
      default:
        return null;
    }
  };

  const getDueDateDisplay = (dueDate: Date, status: string) => {
    const isOverdue = status === 'overdue';
    const now = new Date();
    const tomorrow = new Date(now);
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    const isToday = dueDate.toDateString() === now.toDateString();
    const isTomorrow = dueDate.toDateString() === tomorrow.toDateString();
    
    let dateDisplay;
    if (isToday) {
      dateDisplay = `Today, ${format(dueDate, 'h:mm a')}`;
    } else if (isTomorrow) {
      dateDisplay = `Tomorrow, ${format(dueDate, 'h:mm a')}`;
    } else {
      dateDisplay = format(dueDate, 'MMM d, h:mm a');
    }
    
    return (
      <div className="flex items-center">
        <i className={`${isOverdue ? 'ri-error-warning-line' : 'ri-time-line'} mr-1 ${isOverdue ? 'text-error-500' : ''}`}></i>
        <span className={isOverdue ? 'text-error-500' : ''}>{dateDisplay}</span>
      </div>
    );
  };

  return (
    <div className="overflow-x-auto">
      <table className="min-w-full divide-y divide-neutral-200 dark:divide-neutral-800">
        <thead className="bg-neutral-50 dark:bg-neutral-900">
          <tr>
            <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">
              Assignment
            </th>
            <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">
              Course
            </th>
            <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">
              Due Date
            </th>
            <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">
              Status
            </th>
            <th scope="col" className="px-4 py-3 text-right text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">
              Action
            </th>
          </tr>
        </thead>
        <tbody className="bg-white dark:bg-neutral-900 divide-y divide-neutral-200 dark:divide-neutral-800">
          {assignments.map((assignment) => (
            <tr key={assignment.id}>
              <td className="px-4 py-3 whitespace-nowrap">
                <div className="flex items-center">
                  <div className={`h-8 w-8 rounded-full bg-${assignment.iconColor}-100 dark:bg-${assignment.iconColor}-900/30 flex items-center justify-center text-${assignment.iconColor}-500 mr-3`}>
                    <i className={assignment.icon}></i>
                  </div>
                  <div>
                    <div className="text-sm font-medium text-neutral-900 dark:text-neutral-100">{assignment.title}</div>
                    <div className="text-xs text-neutral-500 dark:text-neutral-400">{assignment.points} points</div>
                  </div>
                </div>
              </td>
              <td className="px-4 py-3 whitespace-nowrap text-sm text-neutral-900 dark:text-neutral-100">
                {assignment.courseName}
              </td>
              <td className="px-4 py-3 whitespace-nowrap text-sm text-neutral-500 dark:text-neutral-400">
                {getDueDateDisplay(assignment.dueDate, assignment.status)}
              </td>
              <td className="px-4 py-3 whitespace-nowrap">
                {getStatusBadge(assignment.status)}
              </td>
              <td className="px-4 py-3 whitespace-nowrap text-right text-sm font-medium">
                {getActionButton(assignment.status, assignment.id)}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
