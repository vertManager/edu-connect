import { formatDistanceToNow } from "date-fns";

export interface AnnouncementCardProps {
  title: string;
  content: string;
  date: Date;
  author: string;
  course: string;
}

export default function AnnouncementCard({
  title,
  content,
  date,
  author,
  course
}: AnnouncementCardProps) {
  const timeAgo = formatDistanceToNow(new Date(date), { addSuffix: true });
  
  return (
    <div className="p-4 border-b last:border-b-0 border-neutral-200 dark:border-neutral-800">
      <div className="flex justify-between mb-1">
        <h3 className="font-medium">{title}</h3>
        <span className="text-xs text-neutral-500 dark:text-neutral-400">{timeAgo}</span>
      </div>
      <p className="text-sm text-neutral-600 dark:text-neutral-400 mb-2">
        {content}
      </p>
      <div className="flex items-center text-xs text-primary-500">
        <span>{author}</span>
        <span className="mx-2">•</span>
        <span>{course}</span>
      </div>
    </div>
  );
}
