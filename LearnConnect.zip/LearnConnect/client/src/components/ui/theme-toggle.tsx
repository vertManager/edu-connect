import { useTheme } from "@/hooks/use-theme";
import { cn } from "@/lib/utils";

interface ThemeToggleProps {
  className?: string;
}

export function ThemeToggle({ className }: ThemeToggleProps) {
  const { theme, setTheme } = useTheme();
  
  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark");
  };

  return (
    <label className={cn("relative inline-block", className)}>
      <input 
        type="checkbox" 
        className="sr-only" 
        checked={theme === "dark"} 
        onChange={toggleTheme}
      />
      <div className={`h-6 w-12 rounded-full relative cursor-pointer transition-colors duration-300 ease-in-out ${
        theme === "dark" ? "bg-primary-500" : "bg-neutral-300"
      }`}>
        <div className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white transition-transform duration-300 ease-in-out ${
          theme === "dark" ? "translate-x-6" : ""
        }`} />
      </div>
    </label>
  );
}
