import { Link, useLocation } from "wouter";
import { ThemeToggle } from "@/components/ui/theme-toggle";
import { useAuth } from "@/context/auth-context";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

interface SidebarProps {
  isMobile?: boolean;
  onNavItemClick?: () => void;
}

export default function Sidebar({ isMobile = false, onNavItemClick }: SidebarProps) {
  const [location] = useLocation();
  const { user, logout } = useAuth();

  const navItems = [
    { path: "/dashboard", icon: "ri-dashboard-line", label: "Dashboard" },
    { path: "/courses", icon: "ri-book-open-line", label: "Courses" },
    { path: "/assignments", icon: "ri-task-line", label: "Assignments" },
    { path: "/grades", icon: "ri-bar-chart-line", label: "Grades" },
    { path: "/calendar", icon: "ri-calendar-line", label: "Calendar" },
    { path: "/messages", icon: "ri-message-2-line", label: "Messages", badge: 3 },
    { path: "/resources", icon: "ri-folder-line", label: "Resources" },
  ];

  const handleNavClick = () => {
    if (onNavItemClick) {
      onNavItemClick();
    }
  };

  return (
    <aside className={`${isMobile ? '' : 'hidden md:flex'} flex-col w-64 bg-white dark:bg-neutral-900 shadow-md z-10`}>
      <div className="p-4 border-b border-neutral-200 dark:border-neutral-800">
        <h1 className="text-2xl font-bold text-primary-500">EduConnect</h1>
      </div>
      
      {/* User Profile Overview */}
      <div className="flex items-center p-4 border-b border-neutral-200 dark:border-neutral-800">
        <Avatar className="h-10 w-10 mr-3">
          <AvatarImage src={user?.profileImage} alt={user?.name} />
          <AvatarFallback className="bg-primary-100 text-primary-800 dark:bg-primary-900 dark:text-primary-200">
            {user?.name?.substring(0, 2).toUpperCase()}
          </AvatarFallback>
        </Avatar>
        <div>
          <p className="font-semibold">{user?.name}</p>
          <p className="text-sm text-neutral-500 dark:text-neutral-400 capitalize">{user?.role}</p>
        </div>
      </div>
      
      {/* Nav Links */}
      <nav className="flex-1 overflow-y-auto py-4">
        <ul>
          {navItems.map((item) => {
            const isActive = location === item.path || 
              (item.path === "/courses" && location.startsWith("/courses/")) ||
              (item.path === "/assignments" && location.startsWith("/assignments/"));
            
            return (
              <li key={item.path}>
                <Link 
                  href={item.path}
                  onClick={handleNavClick}
                  className={`flex items-center px-4 py-3 ${
                    isActive 
                      ? "text-primary-500 bg-primary-50 dark:bg-primary-900/30 border-l-4 border-primary-500" 
                      : "text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800 border-l-4 border-transparent"
                  }`}
                >
                  <i className={`${item.icon} mr-3 text-lg`}></i>
                  <span>{item.label}</span>
                  {item.badge && (
                    <span className="ml-auto bg-primary-500 text-white px-2 py-0.5 rounded-full text-xs">
                      {item.badge}
                    </span>
                  )}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
      
      {/* Theme Toggle & Settings */}
      <div className="p-4 border-t border-neutral-200 dark:border-neutral-800">
        <div className="flex items-center justify-between">
          <span className="text-sm font-medium">Dark Mode</span>
          <ThemeToggle />
        </div>
        <Link 
          href="#settings" 
          className="flex items-center mt-4 text-sm text-neutral-700 dark:text-neutral-300 hover:text-primary-500 dark:hover:text-primary-400"
        >
          <i className="ri-settings-4-line mr-2"></i>
          <span>Settings</span>
        </Link>
        <button 
          onClick={logout}
          className="flex items-center w-full mt-4 text-sm text-neutral-700 dark:text-neutral-300 hover:text-primary-500 dark:hover:text-primary-400"
        >
          <i className="ri-logout-box-line mr-2"></i>
          <span>Logout</span>
        </button>
      </div>
    </aside>
  );
}
