import { Link, useLocation } from "wouter";

export default function MobileNav() {
  const [location] = useLocation();

  const navItems = [
    { path: "/dashboard", icon: "ri-dashboard-line", label: "Dashboard" },
    { path: "/courses", icon: "ri-book-open-line", label: "Courses" },
    { path: "/assignments", icon: "ri-task-line", label: "Assignments" },
    { path: "/calendar", icon: "ri-calendar-line", label: "Calendar" },
    { path: "/more", icon: "ri-more-line", label: "More" },
  ];

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white dark:bg-neutral-900 shadow-lg border-t border-neutral-200 dark:border-neutral-800 px-4 py-2 flex justify-around">
      {navItems.map((item) => {
        const isActive = location === item.path || 
          (item.path === "/courses" && location.startsWith("/courses/")) ||
          (item.path === "/assignments" && location.startsWith("/assignments/"));
          
        return (
          <Link 
            key={item.path} 
            href={item.path}
            className={`flex flex-col items-center ${
              isActive ? 'text-primary-500' : 'text-neutral-500 dark:text-neutral-400'
            }`}
          >
            <i className={`${item.icon} text-xl`}></i>
            <span className="text-xs mt-1">{item.label}</span>
          </Link>
        );
      })}
    </nav>
  );
}
