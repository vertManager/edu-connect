import { useState, useEffect } from "react";
import { useAuth } from "@/context/auth-context";
import { useLocation, useRoute } from "wouter";
import Sidebar from "./sidebar";
import MobileNav from "./mobile-nav";
import { useMobile } from "@/hooks/use-mobile";
import { useToast } from "@/hooks/use-toast";

interface AppLayoutProps {
  children: React.ReactNode;
}

export default function AppLayout({ children }: AppLayoutProps) {
  const { user, isAuthenticated, isLoading } = useAuth();
  const [location, navigate] = useLocation();
  const [, params] = useRoute("/*");
  const isMobile = useMobile();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { toast } = useToast();
  
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      navigate("/login");
      toast({
        title: "Authentication required",
        description: "Please log in to continue",
        variant: "destructive"
      });
    }
  }, [isLoading, isAuthenticated, navigate, toast]);

  if (isLoading) {
    return (
      <div className="min-h-screen w-full flex items-center justify-center bg-background">
        <div className="flex flex-col items-center">
          <div className="h-12 w-12 border-t-4 border-b-4 border-primary rounded-full animate-spin"></div>
          <p className="mt-4 text-lg font-medium">Loading...</p>
        </div>
      </div>
    );
  }

  // If not authenticated, don't render anything (redirect effect will handle navigation)
  if (!isAuthenticated || !user) {
    return null;
  }

  return (
    <div className="flex flex-col md:flex-row min-h-screen bg-neutral-100 dark:bg-neutral-950">
      {/* Desktop Sidebar */}
      <Sidebar isMobile={false} />
      
      {/* Mobile Sidebar (visible when menu is open) */}
      {isMobile && isMobileMenuOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-40"
          onClick={() => setIsMobileMenuOpen(false)}
        >
          <div 
            className="absolute left-0 top-0 h-full w-64 bg-white dark:bg-neutral-900"
            onClick={(e) => e.stopPropagation()}
          >
            <Sidebar isMobile={true} onNavItemClick={() => setIsMobileMenuOpen(false)} />
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col">
        {/* Top Header */}
        <header className="bg-white dark:bg-neutral-900 shadow-sm py-3 px-4 md:px-6 flex items-center justify-between">
          {/* Mobile Menu Trigger */}
          {isMobile && (
            <button 
              className="text-neutral-700 dark:text-neutral-300 hover:text-primary-500 dark:hover:text-primary-400"
              onClick={() => setIsMobileMenuOpen(true)}
            >
              <i className="ri-menu-line text-2xl"></i>
            </button>
          )}
          
          {/* Search Bar (Desktop only) */}
          <div className="hidden md:flex mx-4 flex-1 max-w-xl relative">
            <input
              type="text"
              placeholder="Search courses, assignments, resources..."
              className="w-full px-4 py-2 rounded-md bg-neutral-100 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 focus:outline-none focus:ring-2 focus:ring-primary-500"
            />
            <button className="absolute right-3 top-2 text-neutral-500 dark:text-neutral-400">
              <i className="ri-search-line text-lg"></i>
            </button>
          </div>
          
          {/* Right Side Actions */}
          <div className="flex items-center space-x-4">
            <button className="relative text-neutral-700 dark:text-neutral-300 hover:text-primary-500 dark:hover:text-primary-400">
              <i className="ri-notification-3-line text-xl"></i>
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-primary-500 rounded-full text-white text-xs flex items-center justify-center">2</span>
            </button>
          </div>
        </header>

        {/* Page Content */}
        <div className="flex-1 p-4 md:p-6 overflow-y-auto">
          {children}
        </div>
      </main>

      {/* Mobile Bottom Navigation */}
      {isMobile && <MobileNav />}
    </div>
  );
}
