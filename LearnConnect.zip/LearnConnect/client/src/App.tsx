import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/dashboard";
import Courses from "@/pages/courses";
import CourseDetail from "@/pages/course-detail";
import Assignments from "@/pages/assignments";
import AssignmentDetail from "@/pages/assignment-detail";
import Grades from "@/pages/grades";
import Calendar from "@/pages/calendar";
import Messages from "@/pages/messages";
import Resources from "@/pages/resources";
import More from "@/pages/more";
import Login from "@/pages/login";
import { AuthProvider } from "@/context/auth-context";
import AppLayout from "@/components/layout/app-layout";

function App() {
  const [location] = useLocation();

  // Don't wrap login page in app layout
  const isAuthPage = location === "/login" || location === "/register";

  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        {isAuthPage ? (
          <Switch>
            <Route path="/login" component={Login} />
            <Route path="/register" component={Login} />
          </Switch>
        ) : (
          <AppLayout>
            <Switch>
              <Route path="/" component={Dashboard} />
              <Route path="/dashboard" component={Dashboard} />
              <Route path="/courses" component={Courses} />
              <Route path="/courses/:id" component={CourseDetail} />
              <Route path="/assignments" component={Assignments} />
              <Route path="/assignments/:id" component={AssignmentDetail} />
              <Route path="/grades" component={Grades} />
              <Route path="/calendar" component={Calendar} />
              <Route path="/messages" component={Messages} />
              <Route path="/resources" component={Resources} />
              <Route path="/more" component={More} />
              <Route component={NotFound} />
            </Switch>
          </AppLayout>
        )}
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
