import { useQuery, useMutation } from "@tanstack/react-query";
import { useRoute, Link } from "wouter";
import { useAuth } from "@/context/auth-context";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useState } from "react";

const assignmentFormSchema = z.object({
  title: z.string().min(3, "Assignment title must be at least 3 characters"),
  description: z.string().optional(),
  dueDate: z.string().min(1, "Due date is required"),
  points: z.coerce.number().min(1, "Must be at least 1 point"),
  courseId: z.number().optional(),
});

type AssignmentFormValues = z.infer<typeof assignmentFormSchema>;

export default function CourseDetail() {
  const [, params] = useRoute("/courses/:id");
  const courseId = params?.id ? parseInt(params.id, 10) : null;
  const { user } = useAuth();
  const { toast } = useToast();
  const [createAssignmentOpen, setCreateAssignmentOpen] = useState(false);
  
  // Fetch course details
  const { data: course, isLoading: courseLoading } = useQuery({
    queryKey: [`/api/courses/${courseId}`],
    enabled: !!courseId,
    refetchOnWindowFocus: false,
  });
  
  // Fetch course assignments
  const { data: assignments, isLoading: assignmentsLoading } = useQuery({
    queryKey: [`/api/courses/${courseId}/assignments`],
    enabled: !!courseId,
    refetchOnWindowFocus: false,
  });
  
  // Fetch course announcements
  const { data: announcements, isLoading: announcementsLoading } = useQuery({
    queryKey: [`/api/courses/${courseId}/announcements`],
    enabled: !!courseId,
    refetchOnWindowFocus: false,
  });
  
  // Fetch course resources
  const { data: resources, isLoading: resourcesLoading } = useQuery({
    queryKey: [`/api/courses/${courseId}/resources`],
    enabled: !!courseId,
    refetchOnWindowFocus: false,
  });
  
  // Create assignment form
  const assignmentForm = useForm<AssignmentFormValues>({
    resolver: zodResolver(assignmentFormSchema),
    defaultValues: {
      title: "",
      description: "",
      dueDate: new Date().toISOString().split('T')[0], // Format as YYYY-MM-DD
      points: 10,
      courseId: courseId || undefined,
    },
  });
  
  // Mutation for creating an assignment
  const createAssignmentMutation = useMutation({
    mutationFn: async (data: AssignmentFormValues) => {
      return apiRequest("POST", `/api/courses/${courseId}/assignments`, data);
    },
    onSuccess: () => {
      toast({
        title: "Assignment created",
        description: "The assignment has been created successfully",
      });
      assignmentForm.reset();
      setCreateAssignmentOpen(false);
      queryClient.invalidateQueries({ queryKey: [`/api/courses/${courseId}/assignments`] });
    },
    onError: (error) => {
      toast({
        title: "Failed to create assignment",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      });
    },
  });
  
  const onSubmitAssignment = (data: AssignmentFormValues) => {
    // Make sure to include the courseId in the data
    const assignmentData = {
      ...data,
      courseId: courseId as number
    };
    createAssignmentMutation.mutate(assignmentData);
  };
  
  // Mutation for enrolling in course
  const enrollMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", `/api/courses/${courseId}/enroll`, {});
    },
    onSuccess: () => {
      toast({
        title: "Enrolled successfully",
        description: "You have been enrolled in the course",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/courses/${courseId}`] });
    },
    onError: (error) => {
      toast({
        title: "Enrollment failed",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      });
    },
  });
  
  // Mutation for unenrolling from course
  const unenrollMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("DELETE", `/api/courses/${courseId}/enroll`, {});
    },
    onSuccess: () => {
      toast({
        title: "Unenrolled successfully",
        description: "You have been unenrolled from the course",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/courses/${courseId}`] });
    },
    onError: (error) => {
      toast({
        title: "Unenrollment failed",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      });
    },
  });
  
  if (courseLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="h-12 w-12 border-t-4 border-b-4 border-primary rounded-full animate-spin"></div>
      </div>
    );
  }
  
  if (!course) {
    return (
      <div className="text-center py-12">
        <h2 className="text-xl font-medium mb-2">Course not found</h2>
        <p className="text-neutral-600 dark:text-neutral-400 mb-6">The course you're looking for doesn't exist or you don't have access to it.</p>
        <Button asChild><Link href="/courses">Back to Courses</Link></Button>
      </div>
    );
  }
  
  const isTeacher = user?.id === course.teacherId || user?.role === 'admin';
  const isEnrolled = course.isEnrolled;
  
  return (
    <div>
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
        <div>
          <div className="flex items-center gap-3">
            <div className={`h-12 w-12 rounded-full flex items-center justify-center text-white text-xl`}
              style={{ backgroundColor: course.color || '#4166B0' }}>
              <i className={course.icon || 'ri-book-open-line'}></i>
            </div>
            <h1 className="text-2xl font-bold text-neutral-900 dark:text-neutral-100">
              {course.name}
            </h1>
          </div>
          <p className="text-neutral-600 dark:text-neutral-400 mt-1">
            {course.description || `Taught by ${course.teacher?.name}`}
          </p>
        </div>
        
        <div className="flex items-center gap-3">
          {!isTeacher && !isEnrolled && (
            <Button onClick={() => enrollMutation.mutate()} disabled={enrollMutation.isPending}>
              {enrollMutation.isPending ? "Enrolling..." : "Enroll in Course"}
            </Button>
          )}
          
          {!isTeacher && isEnrolled && (
            <Button variant="outline" onClick={() => unenrollMutation.mutate()} disabled={unenrollMutation.isPending}>
              {unenrollMutation.isPending ? "Unenrolling..." : "Unenroll"}
            </Button>
          )}
          
          {isTeacher && (
            <Button variant="outline" asChild>
              <Link href={`/courses/${courseId}/edit`}>Edit Course</Link>
            </Button>
          )}
        </div>
      </div>
      
      {/* Course Progress (for students) */}
      {isEnrolled && !isTeacher && (
        <Card className="mb-6">
          <CardContent className="p-4">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <h3 className="font-medium mb-1">Course Progress</h3>
                <p className="text-sm text-neutral-600 dark:text-neutral-400 mb-2">
                  You've completed {course.progress || 0}% of this course
                </p>
              </div>
              <div className="w-full md:w-1/2">
                <Progress value={course.progress || 0} className="h-2" />
              </div>
            </div>
          </CardContent>
        </Card>
      )}
      
      {/* Main Content Tabs */}
      <Tabs defaultValue="assignments" className="w-full">
        <TabsList className="mb-6">
          <TabsTrigger value="assignments">Assignments</TabsTrigger>
          <TabsTrigger value="resources">Resources</TabsTrigger>
          <TabsTrigger value="announcements">Announcements</TabsTrigger>
          {isTeacher && <TabsTrigger value="students">Students</TabsTrigger>}
        </TabsList>
        
        {/* Assignments Tab */}
        <TabsContent value="assignments">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold">Assignments</h2>
            {isTeacher && (
              <Dialog open={createAssignmentOpen} onOpenChange={setCreateAssignmentOpen}>
                <DialogTrigger asChild>
                  <Button>Create Assignment</Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[500px]">
                  <DialogHeader>
                    <DialogTitle>Create New Assignment</DialogTitle>
                  </DialogHeader>
                  <Form {...assignmentForm}>
                    <form onSubmit={assignmentForm.handleSubmit(onSubmitAssignment)} className="space-y-4 pt-4">
                      <FormField
                        control={assignmentForm.control}
                        name="title"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Title</FormLabel>
                            <FormControl>
                              <Input placeholder="Assignment title" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={assignmentForm.control}
                        name="description"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Description</FormLabel>
                            <FormControl>
                              <Textarea placeholder="Assignment instructions..." {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={assignmentForm.control}
                          name="dueDate"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Due Date</FormLabel>
                              <FormControl>
                                <Input 
                                type="date" 
                                {...field} 
                              />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={assignmentForm.control}
                          name="points"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Points</FormLabel>
                              <FormControl>
                                <Input type="number" min="1" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <div className="flex justify-end space-x-3 pt-3">
                        <Button variant="outline" type="button" onClick={() => setCreateAssignmentOpen(false)}>
                          Cancel
                        </Button>
                        <Button type="submit" disabled={createAssignmentMutation.isPending}>
                          {createAssignmentMutation.isPending ? "Creating..." : "Create Assignment"}
                        </Button>
                      </div>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
            )}
          </div>
          
          <div className="space-y-4">
            {assignmentsLoading ? (
              <Card className="animate-pulse">
                <CardContent className="p-6">
                  <div className="h-5 bg-neutral-200 dark:bg-neutral-800 rounded w-1/3 mb-4"></div>
                  <div className="h-4 bg-neutral-200 dark:bg-neutral-800 rounded w-full mb-2"></div>
                  <div className="h-4 bg-neutral-200 dark:bg-neutral-800 rounded w-2/3"></div>
                </CardContent>
              </Card>
            ) : assignments && assignments.length > 0 ? (
              assignments.map((assignment) => (
                <Card key={assignment.id}>
                  <CardContent className="p-4">
                    <div className="flex flex-col md:flex-row justify-between gap-4">
                      <div className="flex-1">
                        <Link href={`/assignments/${assignment.id}`}>
                          <h3 className="font-medium text-lg mb-1 hover:text-primary-500 transition-colors">
                            {assignment.title}
                          </h3>
                        </Link>
                        <p className="text-sm text-neutral-600 dark:text-neutral-400 mb-2">
                          {assignment.description || "No description provided"}
                        </p>
                        <div className="flex flex-wrap gap-3 text-sm">
                          <span className="flex items-center text-neutral-600 dark:text-neutral-400">
                            <i className="ri-calendar-line mr-1"></i>
                            Due: {new Date(assignment.dueDate).toLocaleDateString()}
                          </span>
                          <span className="flex items-center text-neutral-600 dark:text-neutral-400">
                            <i className="ri-medal-line mr-1"></i>
                            {assignment.points} points
                          </span>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-3">
                        {!isTeacher && (
                          <>
                            {assignment.status && (
                              <div className={`px-2 py-1 text-xs rounded-full ${
                                assignment.status === 'submitted' || assignment.status === 'graded' || assignment.status === 'completed'
                                  ? 'bg-success-100 dark:bg-success-900/30 text-success-800 dark:text-success-200'
                                  : assignment.status === 'in_progress'
                                  ? 'bg-primary-100 dark:bg-primary-900/30 text-primary-800 dark:text-primary-200'
                                  : assignment.status === 'overdue'
                                  ? 'bg-error-100 dark:bg-error-900/30 text-error-800 dark:text-error-200'
                                  : 'bg-warning-100 dark:bg-warning-900/30 text-warning-800 dark:text-warning-200'
                              }`}>
                                {assignment.status.replace('_', ' ').charAt(0).toUpperCase() + assignment.status.replace('_', ' ').slice(1)}
                              </div>
                            )}
                            <Button asChild>
                              <Link href={`/assignments/${assignment.id}`}>
                                {assignment.status === 'submitted' || assignment.status === 'graded' ? 'View' : 'Start'}
                              </Link>
                            </Button>
                          </>
                        )}
                        
                        {isTeacher && (
                          <Button asChild>
                            <Link href={`/assignments/${assignment.id}`}>Manage</Link>
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-12">
                  <div className="rounded-full bg-primary-100 dark:bg-primary-900/20 p-4 mb-4">
                    <i className="ri-task-line text-4xl text-primary-500"></i>
                  </div>
                  <h3 className="text-lg font-medium mb-2">No Assignments Yet</h3>
                  <p className="text-center text-neutral-600 dark:text-neutral-400 mb-6 max-w-md">
                    {isTeacher
                      ? "Create your first assignment to get started with this course."
                      : "There are no assignments for this course yet."}
                  </p>
                  {isTeacher && (
                    <Button onClick={() => setCreateAssignmentOpen(true)}>Create Assignment</Button>
                  )}
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>
        
        {/* Resources Tab */}
        <TabsContent value="resources">
          <h2 className="text-xl font-semibold mb-4">Course Resources</h2>
          <div className="space-y-4">
            {resourcesLoading ? (
              <Card className="animate-pulse">
                <CardContent className="p-6">
                  <div className="h-5 bg-neutral-200 dark:bg-neutral-800 rounded w-1/3 mb-4"></div>
                  <div className="h-4 bg-neutral-200 dark:bg-neutral-800 rounded w-full mb-2"></div>
                  <div className="h-4 bg-neutral-200 dark:bg-neutral-800 rounded w-2/3"></div>
                </CardContent>
              </Card>
            ) : resources && resources.length > 0 ? (
              resources.map((resource) => (
                <Card key={resource.id}>
                  <CardContent className="p-4">
                    <div className="flex items-start gap-4">
                      <div className={`h-10 w-10 rounded-full bg-primary-100 dark:bg-primary-900/50 flex items-center justify-center text-primary-500 flex-shrink-0 mt-1`}>
                        <i className={resource.type === 'document' ? 'ri-file-text-line' :
                          resource.type === 'image' ? 'ri-image-line' :
                          resource.type === 'video' ? 'ri-video-line' :
                          resource.type === 'audio' ? 'ri-music-line' : 'ri-file-line'}>
                        </i>
                      </div>
                      <div className="flex-1">
                        <h3 className="font-medium text-lg mb-1">{resource.title}</h3>
                        <p className="text-sm text-neutral-600 dark:text-neutral-400 mb-2">
                          {resource.description || "No description provided"}
                        </p>
                        <div className="flex justify-between items-center">
                          <div className="flex items-center text-sm text-neutral-600 dark:text-neutral-400">
                            <i className="ri-user-line mr-1"></i>
                            Added by {resource.creator?.name || "Unknown"}
                          </div>
                          <Button size="sm" asChild>
                            <a href={resource.url} target="_blank" rel="noopener noreferrer">Download</a>
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-12">
                  <div className="rounded-full bg-primary-100 dark:bg-primary-900/20 p-4 mb-4">
                    <i className="ri-folder-line text-4xl text-primary-500"></i>
                  </div>
                  <h3 className="text-lg font-medium mb-2">No Resources Yet</h3>
                  <p className="text-center text-neutral-600 dark:text-neutral-400 mb-6 max-w-md">
                    {isTeacher
                      ? "Upload materials, readings, and other resources for your students."
                      : "There are no resources for this course yet."}
                  </p>
                  {isTeacher && (
                    <Button>Upload Resource</Button>
                  )}
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>
        
        {/* Announcements Tab */}
        <TabsContent value="announcements">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold">Announcements</h2>
            {isTeacher && (
              <Button>Create Announcement</Button>
            )}
          </div>
          
          <div className="space-y-4">
            {announcementsLoading ? (
              <Card className="animate-pulse">
                <CardContent className="p-6">
                  <div className="h-5 bg-neutral-200 dark:bg-neutral-800 rounded w-1/3 mb-4"></div>
                  <div className="h-4 bg-neutral-200 dark:bg-neutral-800 rounded w-full mb-2"></div>
                  <div className="h-4 bg-neutral-200 dark:bg-neutral-800 rounded w-2/3"></div>
                </CardContent>
              </Card>
            ) : announcements && announcements.length > 0 ? (
              announcements.map((announcement) => (
                <Card key={announcement.id}>
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="font-medium text-lg">{announcement.title}</h3>
                      <div className="text-sm text-neutral-500 dark:text-neutral-400">
                        {new Date(announcement.createdAt).toLocaleDateString()}
                      </div>
                    </div>
                    <p className="text-neutral-600 dark:text-neutral-400 mb-3">
                      {announcement.content}
                    </p>
                    <div className="text-sm text-primary-500">
                      Posted by {announcement.author?.name || "Unknown"}
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-12">
                  <div className="rounded-full bg-primary-100 dark:bg-primary-900/20 p-4 mb-4">
                    <i className="ri-megaphone-line text-4xl text-primary-500"></i>
                  </div>
                  <h3 className="text-lg font-medium mb-2">No Announcements Yet</h3>
                  <p className="text-center text-neutral-600 dark:text-neutral-400 mb-6 max-w-md">
                    {isTeacher
                      ? "Share important information with your students through announcements."
                      : "There are no announcements for this course yet."}
                  </p>
                  {isTeacher && (
                    <Button>Create Announcement</Button>
                  )}
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>
        
        {/* Students Tab (Teacher only) */}
        {isTeacher && (
          <TabsContent value="students">
            <h2 className="text-xl font-semibold mb-4">Enrolled Students</h2>
            <Card>
              <CardContent className="p-0">
                <div className="relative w-full overflow-auto">
                  <table className="w-full caption-bottom text-sm">
                    <thead className="border-b">
                      <tr className="border-b transition-colors hover:bg-neutral-50 dark:hover:bg-neutral-800/50">
                        <th className="h-12 px-4 text-left align-middle font-medium text-neutral-500 dark:text-neutral-400">Name</th>
                        <th className="h-12 px-4 text-left align-middle font-medium text-neutral-500 dark:text-neutral-400">Username</th>
                        <th className="h-12 px-4 text-left align-middle font-medium text-neutral-500 dark:text-neutral-400">Enrolled On</th>
                        <th className="h-12 px-4 text-right align-middle font-medium text-neutral-500 dark:text-neutral-400">Progress</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr className="border-b transition-colors hover:bg-neutral-50 dark:hover:bg-neutral-800/50">
                        <td className="px-4 py-4 align-middle">Example Student</td>
                        <td className="px-4 py-4 align-middle">student</td>
                        <td className="px-4 py-4 align-middle">Jan 1, 2023</td>
                        <td className="px-4 py-4 align-middle text-right">75%</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        )}
      </Tabs>
    </div>
  );
}
