import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/context/auth-context";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { ThemeToggle } from "@/components/ui/theme-toggle";

export default function More() {
  const { user, logout } = useAuth();

  const moreMenuItems = [
    { path: "/grades", icon: "ri-bar-chart-line", label: "Grades" },
    { path: "/messages", icon: "ri-message-2-line", label: "Messages", badge: 3 },
    { path: "/resources", icon: "ri-folder-line", label: "Resources" },
    { path: "/settings", icon: "ri-settings-4-line", label: "Settings" },
  ];

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">More Options</h1>
      
      {/* User Profile Card */}
      <Card className="mb-6">
        <CardHeader className="pb-3">
          <CardTitle>Profile</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center">
            <Avatar className="h-20 w-20 mr-6">
              <AvatarImage src={user?.profileImage} alt={user?.name} />
              <AvatarFallback className="bg-primary-100 text-primary-800 dark:bg-primary-900 dark:text-primary-200 text-xl">
                {user?.name?.substring(0, 2).toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <div>
              <h2 className="text-xl font-semibold">{user?.name}</h2>
              <p className="text-neutral-600 dark:text-neutral-400 capitalize">{user?.role}</p>
              <p className="text-neutral-500 dark:text-neutral-500">{user?.email}</p>
            </div>
          </div>
          <Separator className="my-4" />
          <Link 
            href="/profile" 
            className="flex items-center text-primary-500 hover:text-primary-600 dark:hover:text-primary-400 font-medium"
          >
            <i className="ri-user-settings-line mr-2"></i>
            <span>Edit Profile</span>
          </Link>
        </CardContent>
      </Card>
      
      {/* Menu Options */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle>Menu</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <ul>
            {moreMenuItems.map((item) => (
              <li key={item.path}>
                <Link
                  href={item.path}
                  className="flex items-center px-6 py-4 hover:bg-neutral-50 dark:hover:bg-neutral-800 border-b border-neutral-200 dark:border-neutral-800 last:border-b-0"
                >
                  <i className={`${item.icon} mr-3 text-xl text-neutral-600 dark:text-neutral-400`}></i>
                  <span className="font-medium">{item.label}</span>
                  {item.badge && (
                    <span className="ml-auto bg-primary-500 text-white px-2 py-0.5 rounded-full text-xs">
                      {item.badge}
                    </span>
                  )}
                </Link>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>
      
      {/* Theme Toggle & Logout */}
      <Card className="mt-6">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <span className="font-medium">Dark Mode</span>
            <ThemeToggle />
          </div>
          <button 
            onClick={logout}
            className="flex items-center w-full mt-4 px-3 py-2 bg-neutral-100 dark:bg-neutral-800 hover:bg-neutral-200 dark:hover:bg-neutral-700 rounded-md"
          >
            <i className="ri-logout-box-line mr-2 text-neutral-700 dark:text-neutral-300"></i>
            <span className="font-medium">Logout</span>
          </button>
        </CardContent>
      </Card>
    </div>
  );
}