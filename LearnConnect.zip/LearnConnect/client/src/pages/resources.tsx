import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/context/auth-context";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useState, useMemo } from "react";
import { Link } from "wouter";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { format } from "date-fns";

const resourceFormSchema = z.object({
  title: z.string().min(3, "Title must be at least 3 characters"),
  description: z.string().optional(),
  type: z.enum(["document", "image", "video", "audio", "other"]),
  url: z.string().url("Must be a valid URL"),
  courseId: z.string().min(1, "Course is required"),
});

type ResourceFormValues = z.infer<typeof resourceFormSchema>;

export default function Resources() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [courseFilter, setCourseFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");
  const [createResourceOpen, setCreateResourceOpen] = useState(false);
  
  // Fetch courses
  const { data: courses } = useQuery({
    queryKey: ['/api/courses'],
    refetchOnWindowFocus: false,
  });
  
  // Fetch resources
  const { data: allResources, isLoading } = useQuery({
    queryKey: ['/api/resources'],
    refetchOnWindowFocus: false,
  });
  
  // Filter resources based on selected filters
  const filteredResources = useMemo(() => {
    if (!allResources) return [];
    
    return allResources.filter(resource => {
      const matchesCourse = courseFilter === "all" || resource.course.id.toString() === courseFilter;
      const matchesType = typeFilter === "all" || resource.type === typeFilter;
      return matchesCourse && matchesType;
    });
  }, [allResources, courseFilter, typeFilter]);
  
  // Group resources by course
  const resourcesByCourse = useMemo(() => {
    if (!filteredResources) return {};
    
    return filteredResources.reduce((acc: Record<string, any[]>, resource) => {
      const courseId = resource.course.id.toString();
      if (!acc[courseId]) {
        acc[courseId] = [];
      }
      acc[courseId].push(resource);
      return acc;
    }, {});
  }, [filteredResources]);
  
  // Resource form
  const form = useForm<ResourceFormValues>({
    resolver: zodResolver(resourceFormSchema),
    defaultValues: {
      title: "",
      description: "",
      type: "document",
      url: "",
      courseId: courses?.[0]?.id.toString() || "",
    },
  });
  
  // Mutation for creating a resource
  const createResourceMutation = useMutation({
    mutationFn: async (data: ResourceFormValues) => {
      return apiRequest("POST", `/api/courses/${data.courseId}/resources`, {
        ...data,
        type: data.type
      });
    },
    onSuccess: () => {
      toast({
        title: "Resource created",
        description: "Your resource has been created successfully",
      });
      form.reset();
      setCreateResourceOpen(false);
      queryClient.invalidateQueries({ queryKey: ['/api/resources'] });
    },
    onError: (error) => {
      toast({
        title: "Failed to create resource",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      });
    },
  });
  
  const onSubmit = (data: ResourceFormValues) => {
    createResourceMutation.mutate(data);
  };
  
  // Resource type icon mapping
  const getResourceTypeIcon = (type: string) => {
    switch (type) {
      case 'document':
        return 'ri-file-text-line';
      case 'image':
        return 'ri-image-line';
      case 'video':
        return 'ri-video-line';
      case 'audio':
        return 'ri-music-line';
      default:
        return 'ri-file-line';
    }
  };
  
  return (
    <div>
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold text-neutral-900 dark:text-neutral-100">Resources</h1>
          <p className="text-neutral-600 dark:text-neutral-400">
            Access course materials and resources
          </p>
        </div>
        
        <Dialog open={createResourceOpen} onOpenChange={setCreateResourceOpen}>
          <DialogTrigger asChild>
            <Button>Upload Resource</Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>Upload New Resource</DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 pt-4">
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Title</FormLabel>
                      <FormControl>
                        <Input placeholder="Resource title" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description</FormLabel>
                      <FormControl>
                        <Textarea placeholder="Resource description..." {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="type"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Resource Type</FormLabel>
                        <Select 
                          value={field.value} 
                          onValueChange={field.onChange}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select a type" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="document">Document</SelectItem>
                            <SelectItem value="image">Image</SelectItem>
                            <SelectItem value="video">Video</SelectItem>
                            <SelectItem value="audio">Audio</SelectItem>
                            <SelectItem value="other">Other</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="courseId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Course</FormLabel>
                        <Select 
                          value={field.value} 
                          onValueChange={field.onChange}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select a course" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {courses?.map(course => (
                              <SelectItem key={course.id} value={course.id.toString()}>
                                {course.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <FormField
                  control={form.control}
                  name="url"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Resource URL</FormLabel>
                      <FormControl>
                        <Input placeholder="https://example.com/resource" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="flex justify-end space-x-3 pt-3">
                  <Button variant="outline" type="button" onClick={() => setCreateResourceOpen(false)}>
                    Cancel
                  </Button>
                  <Button type="submit" disabled={createResourceMutation.isPending}>
                    {createResourceMutation.isPending ? "Uploading..." : "Upload Resource"}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>
      
      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <div className="flex-1">
          <Select value={courseFilter} onValueChange={setCourseFilter}>
            <SelectTrigger>
              <SelectValue placeholder="Filter by course" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Courses</SelectItem>
              {courses?.map(course => (
                <SelectItem key={course.id} value={course.id.toString()}>
                  {course.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        <div className="flex-1">
          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger>
              <SelectValue placeholder="Filter by type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="document">Documents</SelectItem>
              <SelectItem value="image">Images</SelectItem>
              <SelectItem value="video">Videos</SelectItem>
              <SelectItem value="audio">Audio</SelectItem>
              <SelectItem value="other">Other</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      
      {isLoading ? (
        <div className="space-y-6">
          {[1, 2].map(i => (
            <Card key={i} className="animate-pulse">
              <CardHeader className="pb-2">
                <div className="h-6 bg-neutral-200 dark:bg-neutral-800 rounded w-1/3"></div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[1, 2, 3].map(j => (
                    <div key={j} className="flex gap-4">
                      <div className="h-10 w-10 rounded-full bg-neutral-200 dark:bg-neutral-800"></div>
                      <div className="flex-1 space-y-2">
                        <div className="h-4 bg-neutral-200 dark:bg-neutral-800 rounded w-1/2"></div>
                        <div className="h-3 bg-neutral-200 dark:bg-neutral-800 rounded w-full"></div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : Object.keys(resourcesByCourse).length > 0 ? (
        <div className="space-y-6">
          {courseFilter === "all" ? (
            // Group by course when showing all courses
            Object.entries(resourcesByCourse).map(([courseId, resources]) => {
              const course = courses?.find(c => c.id.toString() === courseId);
              if (!course) return null;
              
              return (
                <Card key={courseId}>
                  <CardHeader className="pb-2">
                    <CardTitle className="flex items-center gap-2">
                      <div 
                        className="w-6 h-6 rounded-full flex items-center justify-center text-white text-xs"
                        style={{ backgroundColor: course.color || '#4166B0' }}
                      >
                        <i className={course.icon || 'ri-book-open-line'}></i>
                      </div>
                      <Link href={`/courses/${course.id}`} className="hover:text-primary-500">
                        {course.name}
                      </Link>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4 divide-y divide-neutral-200 dark:divide-neutral-800">
                      {resources.map(resource => (
                        <div key={resource.id} className="pt-4 first:pt-0">
                          <div className="flex items-start gap-4">
                            <div className="h-10 w-10 rounded-full bg-primary-100 dark:bg-primary-900/50 flex items-center justify-center text-primary-500 flex-shrink-0">
                              <i className={getResourceTypeIcon(resource.type)}></i>
                            </div>
                            <div className="flex-1">
                              <h3 className="font-medium text-lg">{resource.title}</h3>
                              {resource.description && (
                                <p className="text-sm text-neutral-600 dark:text-neutral-400 mb-2">
                                  {resource.description}
                                </p>
                              )}
                              <div className="flex flex-wrap justify-between items-center gap-2">
                                <div className="flex items-center text-sm text-neutral-500 dark:text-neutral-400">
                                  <Avatar className="h-5 w-5 mr-1">
                                    <AvatarImage src={resource.creator?.profileImage} />
                                    <AvatarFallback className="text-[10px]">
                                      {resource.creator?.name?.substring(0, 2).toUpperCase()}
                                    </AvatarFallback>
                                  </Avatar>
                                  <span>{resource.creator?.name}</span>
                                  <span className="mx-2">•</span>
                                  <span>{format(new Date(resource.createdAt), 'MMM d, yyyy')}</span>
                                </div>
                                <Button size="sm" asChild>
                                  <a href={resource.url} target="_blank" rel="noopener noreferrer">
                                    <i className="ri-download-line mr-1"></i> Download
                                  </a>
                                </Button>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              );
            })
          ) : (
            // Flat list when filtered by course
            <Card>
              <CardContent className="p-0">
                <div className="space-y-4 divide-y divide-neutral-200 dark:divide-neutral-800 p-6">
                  {filteredResources.map(resource => (
                    <div key={resource.id} className="pt-4 first:pt-0">
                      <div className="flex items-start gap-4">
                        <div className="h-10 w-10 rounded-full bg-primary-100 dark:bg-primary-900/50 flex items-center justify-center text-primary-500 flex-shrink-0">
                          <i className={getResourceTypeIcon(resource.type)}></i>
                        </div>
                        <div className="flex-1">
                          <h3 className="font-medium text-lg">{resource.title}</h3>
                          {resource.description && (
                            <p className="text-sm text-neutral-600 dark:text-neutral-400 mb-2">
                              {resource.description}
                            </p>
                          )}
                          <div className="flex flex-wrap justify-between items-center gap-2">
                            <div className="flex items-center text-sm text-neutral-500 dark:text-neutral-400">
                              <Avatar className="h-5 w-5 mr-1">
                                <AvatarImage src={resource.creator?.profileImage} />
                                <AvatarFallback className="text-[10px]">
                                  {resource.creator?.name?.substring(0, 2).toUpperCase()}
                                </AvatarFallback>
                              </Avatar>
                              <span>{resource.creator?.name}</span>
                              <span className="mx-2">•</span>
                              <span>{format(new Date(resource.createdAt), 'MMM d, yyyy')}</span>
                            </div>
                            <Button size="sm" asChild>
                              <a href={resource.url} target="_blank" rel="noopener noreferrer">
                                <i className="ri-download-line mr-1"></i> Download
                              </a>
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      ) : (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <div className="rounded-full bg-primary-100 dark:bg-primary-900/20 p-4 mb-4">
              <i className="ri-folder-line text-4xl text-primary-500"></i>
            </div>
            <h3 className="text-lg font-medium mb-2">No Resources Found</h3>
            <p className="text-center text-neutral-600 dark:text-neutral-400 mb-6 max-w-md">
              {typeFilter !== "all"
                ? `No ${typeFilter} resources found. Try a different filter or upload a new resource.`
                : "No resources have been uploaded yet. Upload a resource to get started."}
            </p>
            <Button onClick={() => setCreateResourceOpen(true)}>Upload Resource</Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
