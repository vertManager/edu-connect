import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import CourseCard from "@/components/dashboard/course-card";
import AnnouncementCard from "@/components/dashboard/announcement-card";
import AssignmentTable from "@/components/dashboard/assignment-table";
import QuickActionCard from "@/components/dashboard/quick-action-card";
import WeeklySchedule from "@/components/dashboard/weekly-schedule";
import { useAuth } from "@/context/auth-context";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

interface DashboardStats {
  upcomingAssignments: number;
  todayClasses: number;
  unreadMessages: number;
  newGrades: number;
}

export default function Dashboard() {
  const { user } = useAuth();
  
  // Fetch dashboard statistics
  const { data: stats } = useQuery<DashboardStats>({
    queryKey: ['/api/dashboard/stats'],
    refetchOnWindowFocus: false,
  });
  
  // Fetch courses
  const { data: courses } = useQuery({
    queryKey: ['/api/courses'],
    refetchOnWindowFocus: false,
  });
  
  // Fetch announcements
  const { data: announcements } = useQuery({
    queryKey: ['/api/announcements'],
    refetchOnWindowFocus: false,
  });
  
  // Fetch upcoming assignments
  const { data: assignments } = useQuery({
    queryKey: ['/api/assignments'],
    refetchOnWindowFocus: false,
  });
  
  // Fetch schedule events
  const { data: events } = useQuery({
    queryKey: ['/api/events'],
    refetchOnWindowFocus: false,
  });
  
  // Format courses data for course cards
  const formattedCourses = courses?.map(course => {
    // Find next class for this course
    const nextClassEvent = events?.find(event => 
      event.course?.id === course.id && new Date(event.startTime) > new Date()
    );

    // Format next class date/time
    let nextClass;
    if (nextClassEvent) {
      const eventDate = new Date(nextClassEvent.startTime);
      const today = new Date();
      const tomorrow = new Date(today);
      tomorrow.setDate(tomorrow.getDate() + 1);
      
      let dateText;
      if (eventDate.toDateString() === today.toDateString()) {
        dateText = 'Today';
      } else if (eventDate.toDateString() === tomorrow.toDateString()) {
        dateText = 'Tomorrow';
      } else {
        const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
        dateText = days[eventDate.getDay()];
      }
      
      const timeText = eventDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      
      nextClass = {
        date: dateText,
        time: timeText
      };
    }
    
    // Count assignments for this course
    const courseAssignments = assignments?.filter(a => a.course.id === course.id) || [];
    const overdueCount = courseAssignments.filter(a => a.status === 'overdue').length;
    const pendingCount = courseAssignments.filter(a => 
      a.status !== 'completed' && a.status !== 'submitted' && a.status !== 'graded' && a.status !== 'overdue'
    ).length;
    
    let assignmentStatus;
    if (overdueCount > 0) {
      assignmentStatus = 'overdue';
    } else if (pendingCount > 0) {
      assignmentStatus = 'pending';
    } else {
      assignmentStatus = 'none';
    }
    
    return {
      id: course.id,
      name: course.name,
      teacherName: course.teacher?.name || 'Unknown',
      color: course.color || '#4166B0',
      icon: course.icon || 'ri-book-open-line',
      nextClass,
      progress: course.progress || 0,
      assignments: {
        count: courseAssignments.length,
        status: assignmentStatus,
      },
    };
  });
  
  // Format assignments for assignment table
  const formattedAssignments = assignments?.slice(0, 4).map(assignment => {
    // Determine icon based on course
    const course = courses?.find(c => c.id === assignment.course.id);
    let icon = 'ri-file-text-line';
    let iconColor = 'primary';
    
    if (course) {
      // Extract icon from course, or use a default based on name
      if (course.icon) {
        icon = course.icon;
      } else if (course.name.toLowerCase().includes('biology')) {
        icon = 'ri-microscope-line';
        iconColor = 'primary';
      } else if (course.name.toLowerCase().includes('computer')) {
        icon = 'ri-code-box-line';
        iconColor = 'secondary';
      } else if (course.name.toLowerCase().includes('english')) {
        icon = 'ri-draft-line';
        iconColor = 'accent';
      } else if (course.name.toLowerCase().includes('math')) {
        icon = 'ri-file-chart-line';
        iconColor = 'success';
      }
    }
    
    return {
      id: assignment.id,
      title: assignment.title,
      courseId: assignment.course.id,
      courseName: assignment.course.name,
      points: assignment.points,
      dueDate: new Date(assignment.dueDate),
      status: assignment.status,
      icon,
      iconColor,
    };
  });
  
  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-neutral-900 dark:text-neutral-100">Dashboard</h1>
        <p className="text-neutral-600 dark:text-neutral-400">Welcome back, {user?.name}</p>
      </div>
      
      {/* Quick Actions Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4 mb-8">
        <QuickActionCard
          icon="ri-task-line"
          iconColor="primary"
          title="Upcoming Assignments"
          value={`${stats?.upcomingAssignments || 0} due this week`}
          linkTo="/assignments"
        />
        
        <QuickActionCard
          icon="ri-calendar-check-line"
          iconColor="secondary"
          title="Today's Schedule"
          value={`${stats?.todayClasses || 0} classes today`}
          linkTo="/calendar"
          bgColorClass="bg-secondary-100 dark:bg-secondary-900/30"
        />
        
        <QuickActionCard
          icon="ri-message-2-line"
          iconColor="accent"
          title="New Messages"
          value={`${stats?.unreadMessages || 0} unread messages`}
          linkTo="/messages"
          bgColorClass="bg-accent-100 dark:bg-accent-900/30"
        />
        
        <QuickActionCard
          icon="ri-bar-chart-line"
          iconColor="success"
          title="Grade Updates"
          value={`${stats?.newGrades || 0} new grades posted`}
          linkTo="/grades"
          bgColorClass="bg-success-100 dark:bg-success-900/30"
        />
      </div>
      
      {/* Recent Activity & Announcements */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        {/* Recently Active Courses */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Your Courses</CardTitle>
              <Button variant="link" asChild>
                <Link href="/courses">View All</Link>
              </Button>
            </CardHeader>
            
            <CardContent>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {formattedCourses?.slice(0, 4).map(course => (
                  <CourseCard key={course.id} {...course} />
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* Announcements */}
        <div>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Announcements</CardTitle>
              <Button variant="link">View All</Button>
            </CardHeader>
            
            <CardContent className="p-0">
              <div className="divide-y divide-neutral-200 dark:divide-neutral-800">
                {announcements?.slice(0, 3).map(announcement => (
                  <AnnouncementCard
                    key={announcement.id}
                    title={announcement.title}
                    content={announcement.content}
                    date={new Date(announcement.createdAt)}
                    author={announcement.author?.name || 'Unknown'}
                    course={announcement.courseName || 'System Wide'}
                  />
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
      
      {/* Upcoming Assignments */}
      <div className="mb-8">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Upcoming Assignments</CardTitle>
            <Button variant="link" asChild>
              <Link href="/assignments">View All</Link>
            </Button>
          </CardHeader>
          
          <CardContent>
            {formattedAssignments?.length ? (
              <AssignmentTable assignments={formattedAssignments} />
            ) : (
              <div className="text-center py-8 text-neutral-500 dark:text-neutral-400">
                <p>No upcoming assignments</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
      
      {/* Weekly Schedule Preview */}
      <div>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>This Week's Schedule</CardTitle>
            <Button variant="link" asChild>
              <Link href="/calendar">View Calendar</Link>
            </Button>
          </CardHeader>
          
          <CardContent>
            <WeeklySchedule events={events || []} />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
