import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/context/auth-context";
import { useState, useMemo } from "react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { format, startOfWeek, endOfWeek, eachDayOfInterval, isSameDay, addDays, isToday, addWeeks, subWeeks, startOfDay, getHours, getMinutes } from 'date-fns';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";

const eventFormSchema = z.object({
  title: z.string().min(3, "Title must be at least 3 characters"),
  description: z.string().optional(),
  location: z.string().optional(),
  startTime: z.string().min(1, "Start time is required"),
  endTime: z.string().min(1, "End time is required"),
  courseId: z.string().optional().nullable(),
});

type EventFormValues = z.infer<typeof eventFormSchema>;

export default function Calendar() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [currentDate, setCurrentDate] = useState(new Date());
  const [courseFilter, setCourseFilter] = useState("all");
  const [createEventOpen, setCreateEventOpen] = useState(false);
  interface CourseType {
    id: number;
    name: string;
    color?: string;
  }
  
  interface EventType {
    id: number;
    title: string;
    description?: string;
    startTime: string;
    endTime: string;
    location?: string;
    course?: CourseType;
  }
  
  const [selectedEvent, setSelectedEvent] = useState<EventType | null>(null);
  const [selectedEventDialogOpen, setSelectedEventDialogOpen] = useState(false);
  
  // Calculate current week
  const weekStart = startOfWeek(currentDate, { weekStartsOn: 1 });
  const weekEnd = endOfWeek(currentDate, { weekStartsOn: 1 });
  const daysOfWeek = eachDayOfInterval({ start: weekStart, end: weekEnd });
  
  // Fetch courses
  const { data: courses = [] } = useQuery<CourseType[]>({
    queryKey: ['/api/courses'],
    refetchOnWindowFocus: false,
  });
  
  // Fetch events
  const { data: events = [], isLoading } = useQuery<EventType[]>({
    queryKey: ['/api/events'],
    refetchOnWindowFocus: false,
  });
  
  // Filter events based on selected course
  const filteredEvents = useMemo(() => {
    if (!events) return [];
    
    return events.filter(event => {
      const isInSelectedWeek = new Date(event.startTime) >= weekStart && 
                               new Date(event.startTime) <= endOfWeek(weekEnd);
      
      const matchesCourse = courseFilter === "all" || 
                            (courseFilter === "null" && !event.course) ||
                            (event.course?.id.toString() === courseFilter);
      
      return isInSelectedWeek && matchesCourse;
    });
  }, [events, weekStart, weekEnd, courseFilter]);
  
  // Group events by day and time
  const eventsByDay = useMemo(() => {
    const groupedEvents: Record<string, EventType[]> = {};
    
    daysOfWeek.forEach(day => {
      groupedEvents[format(day, 'yyyy-MM-dd')] = [];
    });
    
    filteredEvents.forEach(event => {
      const eventDate = format(new Date(event.startTime), 'yyyy-MM-dd');
      if (groupedEvents[eventDate]) {
        groupedEvents[eventDate].push(event);
      }
    });
    
    // Sort events by start time
    Object.keys(groupedEvents).forEach(date => {
      groupedEvents[date].sort((a, b) => 
        new Date(a.startTime).getTime() - new Date(b.startTime).getTime()
      );
    });
    
    return groupedEvents;
  }, [filteredEvents, daysOfWeek]);
  
  // Event form
  const form = useForm<EventFormValues>({
    resolver: zodResolver(eventFormSchema),
    defaultValues: {
      title: "",
      description: "",
      location: "",
      startTime: `${format(currentDate, 'yyyy-MM-dd')}T09:00`,
      endTime: `${format(currentDate, 'yyyy-MM-dd')}T10:00`,
      courseId: null,
    },
  });
  
  // Mutation for creating an event
  const createEventMutation = useMutation({
    mutationFn: async (data: EventFormValues) => {
      const payload = {
        ...data,
        courseId: data.courseId && data.courseId !== "null" ? parseInt(data.courseId, 10) : null,
      };
      
      return data.courseId && data.courseId !== "null"
        ? apiRequest("POST", `/api/courses/${data.courseId}/events`, payload)
        : apiRequest("POST", "/api/events", payload);
    },
    onSuccess: () => {
      toast({
        title: "Event created",
        description: "Your event has been created successfully",
      });
      form.reset();
      setCreateEventOpen(false);
      queryClient.invalidateQueries({ queryKey: ['/api/events'] });
    },
    onError: (error) => {
      toast({
        title: "Failed to create event",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      });
    },
  });
  
  const onSubmit = (data: EventFormValues) => {
    createEventMutation.mutate(data);
  };
  
  const handleEventClick = (event: EventType) => {
    setSelectedEvent(event);
    setSelectedEventDialogOpen(true);
  };
  
  // Course color map
  const getCourseColor = (courseId?: number | null) => {
    if (!courseId) return "bg-neutral-100 dark:bg-neutral-800 border-neutral-400";
    
    const course = courses?.find(c => c.id === courseId);
    return course?.color 
      ? `bg-opacity-10 dark:bg-opacity-20 border-l-4 border-[${course.color}]` 
      : "bg-primary-100 dark:bg-primary-900/20 border-l-4 border-primary-500";
  };
  
  const getEventTimeLabel = (startTime: string, endTime: string) => {
    const start = new Date(startTime);
    const end = new Date(endTime);
    return `${format(start, 'h:mm a')} - ${format(end, 'h:mm a')}`;
  };
  
  return (
    <div>
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold text-neutral-900 dark:text-neutral-100">Calendar</h1>
          <p className="text-neutral-600 dark:text-neutral-400">
            Manage your class schedule and events
          </p>
        </div>
        
        <div className="flex items-center gap-3">
          <Dialog open={createEventOpen} onOpenChange={setCreateEventOpen}>
            <DialogTrigger asChild>
              <Button>Create Event</Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[500px]">
              <DialogHeader>
                <DialogTitle>Create New Event</DialogTitle>
              </DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 pt-4">
                  <FormField
                    control={form.control}
                    name="title"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Title</FormLabel>
                        <FormControl>
                          <Input placeholder="Event title" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Description</FormLabel>
                        <FormControl>
                          <Textarea placeholder="Event details..." {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="location"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Location</FormLabel>
                        <FormControl>
                          <Input placeholder="Where will this event take place?" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="startTime"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Start Time</FormLabel>
                          <FormControl>
                            <Input type="datetime-local" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="endTime"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>End Time</FormLabel>
                          <FormControl>
                            <Input type="datetime-local" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <FormField
                    control={form.control}
                    name="courseId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Course (optional)</FormLabel>
                        <Select 
                          value={field.value?.toString() || "null"} 
                          onValueChange={field.onChange}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select a course" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="null">Personal Event</SelectItem>
                            {courses?.map(course => (
                              <SelectItem key={course.id} value={course.id.toString()}>
                                {course.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="flex justify-end space-x-3 pt-3">
                    <Button variant="outline" type="button" onClick={() => setCreateEventOpen(false)}>
                      Cancel
                    </Button>
                    <Button type="submit" disabled={createEventMutation.isPending}>
                      {createEventMutation.isPending ? "Creating..." : "Create Event"}
                    </Button>
                  </div>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>
      </div>
      
      {/* Week navigation and filter */}
      <div className="flex flex-col sm:flex-row justify-between items-center gap-4 mb-6">
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setCurrentDate(subWeeks(currentDate, 1))}
          >
            <i className="ri-arrow-left-s-line"></i>
          </Button>
          
          <span className="font-medium">
            {format(weekStart, 'MMM d')} - {format(weekEnd, 'MMM d, yyyy')}
          </span>
          
          <Button
            variant="outline"
            size="sm"
            onClick={() => setCurrentDate(addWeeks(currentDate, 1))}
          >
            <i className="ri-arrow-right-s-line"></i>
          </Button>
          
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setCurrentDate(new Date())}
          >
            Today
          </Button>
        </div>
        
        <Select value={courseFilter} onValueChange={setCourseFilter}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Filter by course" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Events</SelectItem>
            <SelectItem value="null">Personal Events</SelectItem>
            {courses?.map(course => (
              <SelectItem key={course.id} value={course.id.toString()}>
                {course.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      
      {/* Calendar View */}
      <Card>
        <CardContent className="p-0">
          <div className="grid grid-cols-7 border-b">
            {daysOfWeek.map((day, index) => (
              <div 
                key={index} 
                className={`py-2 px-3 text-center border-r last:border-r-0 font-medium ${
                  isToday(day) ? 'bg-primary-50 dark:bg-primary-900/20' : ''
                }`}
              >
                <div className="text-sm text-neutral-500 dark:text-neutral-400">
                  {format(day, 'EEE')}
                </div>
                <div className={`text-lg ${
                  isToday(day) ? 'text-primary-600 dark:text-primary-400' : ''
                }`}>
                  {format(day, 'd')}
                </div>
              </div>
            ))}
          </div>
          
          <div className="grid grid-cols-7 min-h-[500px]">
            {daysOfWeek.map((day, index) => (
              <div 
                key={index} 
                className={`border-r last:border-r-0 p-2 ${
                  isToday(day) ? 'bg-primary-50 dark:bg-primary-900/20' : ''
                }`}
              >
                <div className="space-y-2">
                  {eventsByDay[format(day, 'yyyy-MM-dd')]?.map((event) => (
                    <div 
                      key={event.id}
                      className={`p-2 rounded-md cursor-pointer hover:shadow-md transition-shadow ${getCourseColor(event.course?.id)}`}
                      onClick={() => handleEventClick(event)}
                    >
                      <div className="font-medium text-sm truncate">{event.title}</div>
                      <div className="text-xs text-neutral-600 dark:text-neutral-400">
                        {getEventTimeLabel(event.startTime, event.endTime)}
                      </div>
                      {event.location && (
                        <div className="text-xs text-neutral-500 dark:text-neutral-500 truncate mt-1">
                          <i className="ri-map-pin-line mr-1"></i>
                          {event.location}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
      
      {/* Event Detail Dialog */}
      <Dialog open={selectedEventDialogOpen} onOpenChange={setSelectedEventDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{selectedEvent?.title}</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4 pt-4">
            {selectedEvent?.course && (
              <div className="flex items-center">
                <Badge variant="outline" className="mr-2">Course</Badge>
                <span>{selectedEvent.course.name}</span>
              </div>
            )}
            
            <div className="flex items-center">
              <i className="ri-time-line mr-2 text-neutral-500"></i>
              <div>
                {selectedEvent?.startTime && (
                  <>
                    <div>{format(new Date(selectedEvent.startTime), 'EEEE, MMMM d, yyyy')}</div>
                    <div className="text-neutral-600 dark:text-neutral-400">
                      {selectedEvent?.endTime && getEventTimeLabel(selectedEvent.startTime, selectedEvent.endTime)}
                    </div>
                  </>
                )}
              </div>
            </div>
            
            {selectedEvent?.location && (
              <div className="flex items-start">
                <i className="ri-map-pin-line mr-2 text-neutral-500 mt-0.5"></i>
                <span>{selectedEvent.location}</span>
              </div>
            )}
            
            {selectedEvent?.description && (
              <div className="mt-4">
                <h3 className="font-medium mb-2">Description</h3>
                <p className="text-neutral-700 dark:text-neutral-300">{selectedEvent.description}</p>
              </div>
            )}
            
            <div className="flex justify-end space-x-3 pt-3">
              <Button variant="outline" onClick={() => setSelectedEventDialogOpen(false)}>
                Close
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
