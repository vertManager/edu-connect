import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/context/auth-context";
import { PieChart, Pie, Cell, Legend, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip } from "recharts";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useState, useMemo } from "react";
import { Link } from "wouter";

export default function Grades() {
  const { user } = useAuth();
  const [courseFilter, setCourseFilter] = useState("all");
  
  // Fetch courses
  const { data: courses } = useQuery({
    queryKey: ['/api/courses'],
    refetchOnWindowFocus: false,
  });
  
  // Fetch submissions with grades
  const { data: submissions, isLoading } = useQuery({
    queryKey: ['/api/submissions/user'],
    refetchOnWindowFocus: false,
  });
  
  // Filter submissions based on selected course
  const filteredSubmissions = useMemo(() => {
    if (!submissions) return [];
    
    return submissions.filter(submission => {
      return courseFilter === "all" || submission.assignment.course.id.toString() === courseFilter;
    });
  }, [submissions, courseFilter]);
  
  // Calculate grade statistics
  const gradeStats = useMemo(() => {
    if (!filteredSubmissions) return null;
    
    const gradedSubmissions = filteredSubmissions.filter(sub => sub.grade !== null);
    
    if (gradedSubmissions.length === 0) return null;
    
    // Calculate course averages
    const courseGrades: Record<string, { total: number, count: number, name: string }> = {};
    gradedSubmissions.forEach(sub => {
      const courseId = sub.assignment.course.id.toString();
      const courseName = sub.assignment.course.name;
      
      if (!courseGrades[courseId]) {
        courseGrades[courseId] = { total: 0, count: 0, name: courseName };
      }
      
      const percentage = (sub.grade / sub.assignment.points) * 100;
      courseGrades[courseId].total += percentage;
      courseGrades[courseId].count += 1;
    });
    
    const courseAverages = Object.keys(courseGrades).map(courseId => ({
      name: courseGrades[courseId].name,
      average: courseGrades[courseId].total / courseGrades[courseId].count
    }));
    
    // Calculate overall grade distribution
    const gradeDistribution = [
      { name: 'A (90-100%)', value: 0, color: '#2ECC71' },
      { name: 'B (80-89%)', value: 0, color: '#3498DB' },
      { name: 'C (70-79%)', value: 0, color: '#F39C12' },
      { name: 'D (60-69%)', value: 0, color: '#E67E22' },
      { name: 'F (0-59%)', value: 0, color: '#E74C3C' },
    ];
    
    gradedSubmissions.forEach(sub => {
      const percentage = (sub.grade / sub.assignment.points) * 100;
      
      if (percentage >= 90) gradeDistribution[0].value += 1;
      else if (percentage >= 80) gradeDistribution[1].value += 1;
      else if (percentage >= 70) gradeDistribution[2].value += 1;
      else if (percentage >= 60) gradeDistribution[3].value += 1;
      else gradeDistribution[4].value += 1;
    });
    
    // Calculate overall average
    const totalPercentage = gradedSubmissions.reduce((acc, sub) => {
      return acc + (sub.grade / sub.assignment.points) * 100;
    }, 0);
    
    const overallAverage = totalPercentage / gradedSubmissions.length;
    
    return {
      overallAverage,
      courseAverages,
      gradeDistribution
    };
  }, [filteredSubmissions]);
  
  const getLetterGrade = (percentage: number) => {
    if (percentage >= 90) return 'A';
    if (percentage >= 80) return 'B';
    if (percentage >= 70) return 'C';
    if (percentage >= 60) return 'D';
    return 'F';
  };
  
  return (
    <div>
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold text-neutral-900 dark:text-neutral-100">Grades</h1>
          <p className="text-neutral-600 dark:text-neutral-400">
            Track your academic performance
          </p>
        </div>
        
        <Select value={courseFilter} onValueChange={setCourseFilter}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Filter by course" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Courses</SelectItem>
            {courses?.map(course => (
              <SelectItem key={course.id} value={course.id.toString()}>
                {course.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {[1, 2, 3, 4].map(i => (
            <Card key={i} className="animate-pulse">
              <CardHeader className="pb-2">
                <div className="h-6 bg-neutral-200 dark:bg-neutral-800 rounded w-1/3"></div>
              </CardHeader>
              <CardContent>
                <div className="h-40 bg-neutral-200 dark:bg-neutral-800 rounded"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : !gradeStats ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <div className="rounded-full bg-primary-100 dark:bg-primary-900/20 p-4 mb-4">
              <i className="ri-bar-chart-line text-4xl text-primary-500"></i>
            </div>
            <h3 className="text-lg font-medium mb-2">No Grades Yet</h3>
            <p className="text-center text-neutral-600 dark:text-neutral-400 mb-6 max-w-md">
              You don't have any graded assignments yet. Once your assignments are graded, you'll see your performance here.
            </p>
          </CardContent>
        </Card>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            {/* Overall Grade */}
            <Card>
              <CardHeader>
                <CardTitle>Overall Grade</CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="flex flex-col items-center">
                  <div className="text-6xl font-bold mb-2 text-primary-500">
                    {getLetterGrade(gradeStats.overallAverage)}
                  </div>
                  <div className="text-xl font-medium">
                    {gradeStats.overallAverage.toFixed(1)}%
                  </div>
                  <p className="text-neutral-600 dark:text-neutral-400 mt-2 text-center">
                    {courseFilter === "all" ? "Average across all courses" : `Average in ${courses?.find(c => c.id.toString() === courseFilter)?.name}`}
                  </p>
                </div>
              </CardContent>
            </Card>
            
            {/* Grade Distribution */}
            <Card>
              <CardHeader>
                <CardTitle>Grade Distribution</CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="h-[250px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={gradeStats.gradeDistribution}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={80}
                        fill="#8884d8"
                        paddingAngle={5}
                        dataKey="value"
                        label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                      >
                        {gradeStats.gradeDistribution.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Course Performance */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Course Performance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={gradeStats.courseAverages}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis domain={[0, 100]} />
                    <Tooltip formatter={(value) => [`${value.toFixed(1)}%`, 'Average']} />
                    <Bar dataKey="average" fill="#4166B0" name="Average Grade %" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
          
          {/* Recent Grades */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Recent Grades</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="relative w-full overflow-auto">
                <table className="w-full caption-bottom text-sm">
                  <thead className="border-b">
                    <tr className="border-b transition-colors hover:bg-neutral-50 dark:hover:bg-neutral-800/50">
                      <th className="h-12 px-4 text-left align-middle font-medium text-neutral-500 dark:text-neutral-400">Assignment</th>
                      <th className="h-12 px-4 text-left align-middle font-medium text-neutral-500 dark:text-neutral-400">Course</th>
                      <th className="h-12 px-4 text-left align-middle font-medium text-neutral-500 dark:text-neutral-400">Submitted</th>
                      <th className="h-12 px-4 text-right align-middle font-medium text-neutral-500 dark:text-neutral-400">Grade</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredSubmissions
                      .filter(submission => submission.grade !== null)
                      .sort((a, b) => new Date(b.submittedAt || 0).getTime() - new Date(a.submittedAt || 0).getTime())
                      .slice(0, 10)
                      .map(submission => (
                        <tr key={submission.id} className="border-b transition-colors hover:bg-neutral-50 dark:hover:bg-neutral-800/50">
                          <td className="px-4 py-4 align-middle">
                            <Link href={`/assignments/${submission.assignment.id}`} className="text-primary-500 hover:underline">
                              {submission.assignment.title}
                            </Link>
                          </td>
                          <td className="px-4 py-4 align-middle">{submission.assignment.course.name}</td>
                          <td className="px-4 py-4 align-middle">
                            {submission.submittedAt ? new Date(submission.submittedAt).toLocaleDateString() : "Not recorded"}
                          </td>
                          <td className="px-4 py-4 align-middle text-right">
                            <span className={`font-medium ${
                              (submission.grade / submission.assignment.points) >= 0.8 ? 'text-success-600 dark:text-success-400' :
                              (submission.grade / submission.assignment.points) >= 0.7 ? 'text-primary-600 dark:text-primary-400' :
                              (submission.grade / submission.assignment.points) >= 0.6 ? 'text-warning-600 dark:text-warning-400' :
                              'text-error-600 dark:text-error-400'
                            }`}>
                              {submission.grade}/{submission.assignment.points}
                            </span>
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}
