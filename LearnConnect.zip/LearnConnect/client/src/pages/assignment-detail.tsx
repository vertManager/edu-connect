import { useQuery, useMutation } from "@tanstack/react-query";
import { useRoute, Link, useLocation } from "wouter";
import { useAuth } from "@/context/auth-context";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";

const submissionFormSchema = z.object({
  content: z.string().min(1, "Submission content is required"),
});

type SubmissionFormValues = z.infer<typeof submissionFormSchema>;

export default function AssignmentDetail() {
  const [, params] = useRoute("/assignments/:id");
  const assignmentId = params?.id ? parseInt(params.id, 10) : null;
  const { user } = useAuth();
  const { toast } = useToast();
  const [, navigate] = useLocation();
  
  // Fetch assignment details
  const { data: assignment, isLoading } = useQuery({
    queryKey: [`/api/assignments/${assignmentId}`],
    enabled: !!assignmentId,
    refetchOnWindowFocus: false,
  });
  
  // Submission form
  const form = useForm<SubmissionFormValues>({
    resolver: zodResolver(submissionFormSchema),
    defaultValues: {
      content: assignment?.submission?.content || "",
    },
  });
  
  // Update form when assignment data is loaded
  useState(() => {
    if (assignment?.submission?.content) {
      form.setValue("content", assignment.submission.content);
    }
  });
  
  // Mutation for submitting assignment
  const submitAssignmentMutation = useMutation({
    mutationFn: async (data: SubmissionFormValues) => {
      return apiRequest("POST", `/api/assignments/${assignmentId}/submit`, data);
    },
    onSuccess: () => {
      toast({
        title: "Assignment submitted",
        description: "Your assignment has been submitted successfully",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/assignments/${assignmentId}`] });
      queryClient.invalidateQueries({ queryKey: ['/api/assignments'] });
    },
    onError: (error) => {
      toast({
        title: "Submission failed",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      });
    },
  });
  
  const onSubmit = (data: SubmissionFormValues) => {
    submitAssignmentMutation.mutate(data);
  };
  
  // Mutation for grading submission
  const gradeSubmissionMutation = useMutation({
    mutationFn: async ({ id, grade, feedback }: { id: number, grade: number, feedback?: string }) => {
      return apiRequest("PUT", `/api/submissions/${id}/grade`, { grade, feedback });
    },
    onSuccess: () => {
      toast({
        title: "Assignment graded",
        description: "The submission has been graded successfully",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/assignments/${assignmentId}`] });
    },
    onError: (error) => {
      toast({
        title: "Grading failed",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      });
    },
  });
  
  const handleGradeSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!assignment?.submission?.id) return;
    
    const formData = new FormData(e.currentTarget);
    const grade = Number(formData.get("grade"));
    const feedback = formData.get("feedback") as string;
    
    if (isNaN(grade) || grade < 0 || grade > (assignment?.points || 0)) {
      toast({
        title: "Invalid grade",
        description: `Grade must be between 0 and ${assignment?.points}`,
        variant: "destructive",
      });
      return;
    }
    
    gradeSubmissionMutation.mutate({ 
      id: assignment.submission.id,
      grade,
      feedback
    });
  };
  
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="h-12 w-12 border-t-4 border-b-4 border-primary rounded-full animate-spin"></div>
      </div>
    );
  }
  
  if (!assignment) {
    return (
      <div className="text-center py-12">
        <h2 className="text-xl font-medium mb-2">Assignment not found</h2>
        <p className="text-neutral-600 dark:text-neutral-400 mb-6">The assignment you're looking for doesn't exist or you don't have access to it.</p>
        <Button asChild><Link href="/assignments">Back to Assignments</Link></Button>
      </div>
    );
  }
  
  const isTeacher = user?.role === 'teacher' || user?.role === 'admin';
  const isSubmitted = assignment.submission?.status === 'submitted' || assignment.submission?.status === 'graded';
  const isOverdue = new Date(assignment.dueDate) < new Date() && !isSubmitted;
  
  const getStatusBadge = () => {
    if (!assignment.submission) {
      return isOverdue ? (
        <Badge variant="destructive">Overdue</Badge>
      ) : (
        <Badge variant="outline">Not Started</Badge>
      );
    }
    
    switch (assignment.submission.status) {
      case 'not_started':
        return <Badge variant="outline">Not Started</Badge>;
      case 'in_progress':
        return <Badge variant="secondary">In Progress</Badge>;
      case 'completed':
        return <Badge variant="success">Completed</Badge>;
      case 'submitted':
        return <Badge variant="success">Submitted</Badge>;
      case 'graded':
        return <Badge variant="primary">Graded</Badge>;
      case 'overdue':
        return <Badge variant="destructive">Overdue</Badge>;
      default:
        return null;
    }
  };
  
  return (
    <div>
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold text-neutral-900 dark:text-neutral-100">
              {assignment.title}
            </h1>
            {getStatusBadge()}
          </div>
          <div className="flex items-center gap-2 mt-1">
            <Link href={`/courses/${assignment.course.id}`} className="text-primary-500 hover:underline">
              {assignment.course.name}
            </Link>
          </div>
        </div>
        
        <div className="flex items-center gap-3">
          <Button variant="outline" asChild>
            <Link href="/assignments">Back to Assignments</Link>
          </Button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Assignment Details</CardTitle>
            </CardHeader>
            <CardContent className="prose dark:prose-invert max-w-none">
              <p>{assignment.description || "No description provided for this assignment."}</p>
            </CardContent>
          </Card>
          
          {!isTeacher && (
            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Your Submission</CardTitle>
              </CardHeader>
              <CardContent>
                {isSubmitted ? (
                  <div>
                    <div className="prose dark:prose-invert max-w-none mb-6">
                      <p>{assignment.submission?.content || "No content submitted."}</p>
                    </div>
                    
                    <div className="text-sm text-neutral-600 dark:text-neutral-400">
                      Submitted: {assignment.submission?.submittedAt ? 
                        new Date(assignment.submission.submittedAt).toLocaleString() : 
                        "Not recorded"}
                    </div>
                    
                    {assignment.submission?.grade !== null && assignment.submission?.grade !== undefined && (
                      <div className="mt-4 p-4 border rounded-md bg-neutral-50 dark:bg-neutral-900">
                        <div className="flex items-center justify-between mb-2">
                          <h3 className="font-medium">Grade</h3>
                          <div className="text-lg font-bold">{assignment.submission.grade}/{assignment.points}</div>
                        </div>
                        
                        {assignment.submission?.feedback && (
                          <div>
                            <h4 className="font-medium text-sm mb-1">Feedback:</h4>
                            <p className="text-neutral-700 dark:text-neutral-300">{assignment.submission.feedback}</p>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                ) : (
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                      <FormField
                        control={form.control}
                        name="content"
                        render={({ field }) => (
                          <FormItem>
                            <FormControl>
                              <Textarea 
                                placeholder="Enter your submission here..." 
                                className="min-h-[200px]"
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <div className="flex justify-end space-x-3">
                        <Button type="submit" disabled={submitAssignmentMutation.isPending}>
                          {submitAssignmentMutation.isPending ? "Submitting..." : isOverdue ? "Submit Late" : "Submit Assignment"}
                        </Button>
                      </div>
                    </form>
                  </Form>
                )}
              </CardContent>
            </Card>
          )}
          
          {isTeacher && assignment.submission && (
            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Student Submission</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="prose dark:prose-invert max-w-none mb-6">
                  <p>{assignment.submission?.content || "No content submitted."}</p>
                </div>
                
                <div className="flex items-center justify-between text-sm text-neutral-600 dark:text-neutral-400 mb-6">
                  <div>
                    Submitted: {assignment.submission?.submittedAt ? 
                      new Date(assignment.submission.submittedAt).toLocaleString() : 
                      "Not recorded"}
                  </div>
                  <div>
                    Student: {/* Display student name */}
                  </div>
                </div>
                
                <Separator className="my-6" />
                
                <h3 className="font-medium mb-4">Grade Submission</h3>
                <form onSubmit={handleGradeSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="grade">Grade (out of {assignment.points})</Label>
                      <Input 
                        type="number" 
                        id="grade" 
                        name="grade" 
                        min="0" 
                        max={assignment.points.toString()} 
                        defaultValue={assignment.submission?.grade?.toString() || ""}
                      />
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="feedback">Feedback</Label>
                    <Textarea 
                      id="feedback" 
                      name="feedback" 
                      placeholder="Provide feedback to the student..."
                      defaultValue={assignment.submission?.feedback || ""}
                    />
                  </div>
                  
                  <div className="flex justify-end space-x-3">
                    <Button type="submit" disabled={gradeSubmissionMutation.isPending}>
                      {gradeSubmissionMutation.isPending ? "Saving..." : "Save Grade"}
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          )}
        </div>
        
        <div>
          <Card>
            <CardHeader>
              <CardTitle>Assignment Information</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Due Date</h3>
                  <p className="font-medium">
                    {new Date(assignment.dueDate).toLocaleDateString(undefined, {
                      weekday: 'long', 
                      year: 'numeric', 
                      month: 'long', 
                      day: 'numeric'
                    })}
                  </p>
                  <p className="text-sm">
                    {new Date(assignment.dueDate).toLocaleTimeString(undefined, {
                      hour: '2-digit',
                      minute: '2-digit'
                    })}
                  </p>
                </div>
                
                <div>
                  <h3 className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Points</h3>
                  <p className="font-medium">{assignment.points} points</p>
                </div>
                
                <div>
                  <h3 className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Course</h3>
                  <p className="font-medium">{assignment.course.name}</p>
                </div>
                
                {assignment.submission?.status === 'graded' && (
                  <div>
                    <h3 className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Your Grade</h3>
                    <p className="font-medium">{assignment.submission.grade}/{assignment.points}</p>
                  </div>
                )}
                
                <div>
                  <h3 className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Status</h3>
                  <div className="mt-1">{getStatusBadge()}</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
