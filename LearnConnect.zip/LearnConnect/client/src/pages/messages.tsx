import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useState, useRef, useEffect } from "react";
import { formatDistanceToNow } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/context/auth-context";

export default function Messages() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedConversation, setSelectedConversation] = useState<any>(null);
  const [newMessage, setNewMessage] = useState("");
  const messageEndRef = useRef<HTMLDivElement>(null);
  
  // Fetch conversations
  const { data: conversations, isLoading: conversationsLoading } = useQuery({
    queryKey: ['/api/messages'],
    refetchOnWindowFocus: false,
  });
  
  // Fetch selected conversation messages
  const { data: conversation, isLoading: messagesLoading } = useQuery({
    queryKey: ['/api/messages/with', selectedConversation?.user?.id],
    enabled: !!selectedConversation?.user?.id,
    refetchInterval: 5000, // Poll for new messages every 5 seconds
  });
  
  // Mutation for sending a message
  const sendMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      return apiRequest("POST", "/api/messages", {
        content,
        toId: selectedConversation?.user?.id
      });
    },
    onSuccess: () => {
      setNewMessage("");
      queryClient.invalidateQueries({ queryKey: ['/api/messages/with', selectedConversation?.user?.id] });
      queryClient.invalidateQueries({ queryKey: ['/api/messages'] });
    },
    onError: (error) => {
      toast({
        title: "Failed to send message",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      });
    },
  });
  
  // Handle sending a message
  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !selectedConversation) return;
    
    sendMessageMutation.mutate(newMessage);
  };
  
  // Scroll to bottom of messages when conversation changes or new messages arrive
  useEffect(() => {
    if (messageEndRef.current) {
      messageEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [conversation]);
  
  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-neutral-900 dark:text-neutral-100">Messages</h1>
        <p className="text-neutral-600 dark:text-neutral-400">Communicate with teachers and classmates</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Conversation List */}
        <Card className="md:col-span-1">
          <CardHeader>
            <CardTitle>Conversations</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {conversationsLoading ? (
              <div className="p-4 space-y-4">
                {[1, 2, 3].map(i => (
                  <div key={i} className="flex items-center animate-pulse">
                    <div className="h-10 w-10 rounded-full bg-neutral-200 dark:bg-neutral-800 mr-3"></div>
                    <div className="space-y-2 flex-1">
                      <div className="h-4 bg-neutral-200 dark:bg-neutral-800 rounded w-1/2"></div>
                      <div className="h-3 bg-neutral-200 dark:bg-neutral-800 rounded w-3/4"></div>
                    </div>
                  </div>
                ))}
              </div>
            ) : conversations?.length ? (
              <ScrollArea className="h-[500px]">
                <div className="divide-y">
                  {conversations.map((convo) => (
                    <div 
                      key={convo.user.id}
                      className={`flex items-center gap-3 p-4 cursor-pointer hover:bg-neutral-50 dark:hover:bg-neutral-800/50 ${
                        selectedConversation?.user?.id === convo.user.id ? 'bg-neutral-100 dark:bg-neutral-800' : ''
                      }`}
                      onClick={() => setSelectedConversation(convo)}
                    >
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={convo.user.profileImage} alt={convo.user.name} />
                        <AvatarFallback className="bg-primary-100 text-primary-800 dark:bg-primary-900 dark:text-primary-200">
                          {convo.user.name.substring(0, 2).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <div className="flex justify-between items-center">
                          <span className="font-medium truncate">{convo.user.name}</span>
                          {convo.unreadCount > 0 && (
                            <span className="ml-2 bg-primary-500 text-white text-xs rounded-full px-2 py-0.5">
                              {convo.unreadCount}
                            </span>
                          )}
                        </div>
                        <div className="flex justify-between items-center text-sm">
                          <p className="text-neutral-600 dark:text-neutral-400 truncate">
                            {convo.lastMessage.isFromUser ? 'You: ' : ''}{convo.lastMessage.content}
                          </p>
                          <span className="text-xs text-neutral-500 whitespace-nowrap ml-2">
                            {formatDistanceToNow(new Date(convo.lastMessage.createdAt), { addSuffix: true })}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            ) : (
              <div className="flex flex-col items-center justify-center p-6">
                <div className="rounded-full bg-primary-100 dark:bg-primary-900/20 p-4 mb-4">
                  <i className="ri-message-3-line text-4xl text-primary-500"></i>
                </div>
                <h3 className="text-lg font-medium mb-2">No Conversations Yet</h3>
                <p className="text-center text-neutral-600 dark:text-neutral-400">
                  Start a new conversation with a teacher or classmate.
                </p>
              </div>
            )}
          </CardContent>
        </Card>
        
        {/* Message View */}
        <Card className="md:col-span-2">
          {selectedConversation ? (
            <>
              <CardHeader className="border-b">
                <div className="flex items-center gap-3">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={selectedConversation.user.profileImage} alt={selectedConversation.user.name} />
                    <AvatarFallback className="bg-primary-100 text-primary-800 dark:bg-primary-900 dark:text-primary-200">
                      {selectedConversation.user.name.substring(0, 2).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <CardTitle>{selectedConversation.user.name}</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="p-0 flex flex-col h-[500px]">
                {messagesLoading ? (
                  <div className="flex-1 p-4 space-y-4">
                    {[1, 2, 3, 4].map(i => (
                      <div key={i} className={`flex ${i % 2 === 0 ? 'justify-end' : ''}`}>
                        <div className={`animate-pulse rounded-lg p-3 max-w-[70%] ${
                          i % 2 === 0 ? 'bg-primary-100 dark:bg-primary-900/20' : 'bg-neutral-100 dark:bg-neutral-800'
                        }`}>
                          <div className="h-4 bg-neutral-200 dark:bg-neutral-700 rounded w-24 mb-2"></div>
                          <div className="h-3 bg-neutral-200 dark:bg-neutral-700 rounded w-32"></div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <>
                    <ScrollArea className="flex-1 p-4">
                      <div className="space-y-4">
                        {conversation?.messages.map((message) => (
                          <div key={message.id} className={`flex ${message.fromMe ? 'justify-end' : ''}`}>
                            <div className={`rounded-lg p-3 max-w-[70%] ${
                              message.fromMe 
                                ? 'bg-primary-100 dark:bg-primary-900/20 text-primary-800 dark:text-primary-200' 
                                : 'bg-neutral-100 dark:bg-neutral-800'
                            }`}>
                              <p className="whitespace-pre-wrap">{message.content}</p>
                              <div className="text-xs text-neutral-500 dark:text-neutral-400 mt-1">
                                {formatDistanceToNow(new Date(message.createdAt), { addSuffix: true })}
                              </div>
                            </div>
                          </div>
                        ))}
                        <div ref={messageEndRef} />
                      </div>
                    </ScrollArea>
                    <Separator />
                    <form onSubmit={handleSendMessage} className="p-4 flex gap-2">
                      <Input
                        placeholder="Type your message..."
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        className="flex-1"
                      />
                      <Button type="submit" disabled={sendMessageMutation.isPending}>
                        {sendMessageMutation.isPending ? <i className="ri-loader-4-line animate-spin"></i> : 'Send'}
                      </Button>
                    </form>
                  </>
                )}
              </CardContent>
            </>
          ) : (
            <CardContent className="flex flex-col items-center justify-center h-[500px]">
              <div className="rounded-full bg-primary-100 dark:bg-primary-900/20 p-4 mb-4">
                <i className="ri-chat-3-line text-4xl text-primary-500"></i>
              </div>
              <h3 className="text-lg font-medium mb-2">Select a Conversation</h3>
              <p className="text-center text-neutral-600 dark:text-neutral-400 max-w-md">
                Choose a conversation from the list to view messages or start a new conversation.
              </p>
            </CardContent>
          )}
        </Card>
      </div>
    </div>
  );
}
