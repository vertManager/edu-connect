import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/context/auth-context";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import CourseCard from "@/components/dashboard/course-card";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

// Form schema for creating a course
const courseFormSchema = z.object({
  name: z.string().min(3, "Course name must be at least 3 characters"),
  description: z.string().optional(),
  color: z.string().regex(/^#[0-9A-F]{6}$/i, "Must be a valid hex color code").default("#4166B0"),
  icon: z.string().default("ri-book-open-line"),
  teacherId: z.number().optional(), // Added teacherId to the schema
});

type CourseFormValues = z.infer<typeof courseFormSchema>;

export default function Courses() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  
  // Fetch courses
  const { data: courses, isLoading } = useQuery({
    queryKey: ['/api/courses'],
    refetchOnWindowFocus: false,
  });
  
  // Form for creating a new course
  const form = useForm<CourseFormValues>({
    resolver: zodResolver(courseFormSchema),
    defaultValues: {
      name: "",
      description: "",
      color: "#4166B0",
      icon: "ri-book-open-line",
    },
  });
  
  // Mutation for creating a course
  const createCourseMutation = useMutation({
    mutationFn: async (data: CourseFormValues) => {
      return apiRequest("POST", "/api/courses", data);
    },
    onSuccess: () => {
      toast({
        title: "Course created",
        description: "Your course has been created successfully",
      });
      form.reset();
      setOpen(false);
      queryClient.invalidateQueries({ queryKey: ['/api/courses'] });
    },
    onError: (error) => {
      toast({
        title: "Failed to create course",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      });
    },
  });
  
  const onSubmit = (data: CourseFormValues) => {
    // Include the current user's ID as the teacherId
    if (user?.id) {
      createCourseMutation.mutate({
        ...data,
        teacherId: user.id
      });
    } else {
      toast({
        title: "Authentication error",
        description: "You must be logged in to create a course",
        variant: "destructive",
      });
    }
  };
  
  // Format courses data for course cards
  const formattedCourses = courses?.map(course => {
    return {
      id: course.id,
      name: course.name,
      teacherName: course.teacher?.name || 'Unknown',
      color: course.color || '#4166B0',
      icon: course.icon || 'ri-book-open-line',
      progress: course.progress || 0,
      assignments: {
        count: 0,
      },
    };
  });
  
  const isTeacher = user?.role === 'teacher' || user?.role === 'admin';
  
  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-neutral-900 dark:text-neutral-100">Courses</h1>
          <p className="text-neutral-600 dark:text-neutral-400">
            {isTeacher 
              ? "Manage your courses and student enrollments"
              : "Browse and enroll in available courses"}
          </p>
        </div>
        
        {isTeacher && (
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button>Create Course</Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
              <DialogHeader>
                <DialogTitle>Create New Course</DialogTitle>
              </DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 pt-4">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Course Name</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g. Introduction to Biology" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Description</FormLabel>
                        <FormControl>
                          <Textarea placeholder="Course description..." {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="color"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Color</FormLabel>
                        <div className="flex items-center space-x-3">
                          <div 
                            className="w-8 h-8 rounded-full border border-neutral-200 dark:border-neutral-700"
                            style={{ backgroundColor: field.value }}
                          />
                          <FormControl>
                            <Input type="color" {...field} />
                          </FormControl>
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="icon"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Icon (Remix Icon class)</FormLabel>
                        <FormControl>
                          <div className="flex items-center space-x-3">
                            <i className={`${field.value} text-2xl text-primary-500`}></i>
                            <Input placeholder="ri-book-open-line" {...field} />
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="flex justify-end space-x-3 pt-3">
                    <Button variant="outline" type="button" onClick={() => setOpen(false)}>
                      Cancel
                    </Button>
                    <Button type="submit" disabled={createCourseMutation.isPending}>
                      {createCourseMutation.isPending ? "Creating..." : "Create Course"}
                    </Button>
                  </div>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        )}
      </div>
      
      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {[1, 2, 3, 4].map(i => (
            <Card key={i} className="animate-pulse">
              <div className="h-28 bg-neutral-200 dark:bg-neutral-800"></div>
              <CardContent className="p-3">
                <div className="h-4 bg-neutral-200 dark:bg-neutral-800 rounded mt-2 mb-3"></div>
                <div className="h-2 bg-neutral-200 dark:bg-neutral-800 rounded mb-3"></div>
                <div className="h-1.5 bg-neutral-200 dark:bg-neutral-800 rounded"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <>
          {formattedCourses?.length ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {formattedCourses.map(course => (
                <CourseCard key={course.id} {...course} />
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center justify-center p-6">
                <div className="rounded-full bg-primary-100 dark:bg-primary-900/20 p-4 mb-4">
                  <i className="ri-book-open-line text-4xl text-primary-500"></i>
                </div>
                <h3 className="text-lg font-medium mb-2">No Courses Found</h3>
                <p className="text-center text-neutral-600 dark:text-neutral-400 mb-6">
                  {isTeacher
                    ? "Create your first course to get started"
                    : "Enroll in courses to get started with your learning journey"}
                </p>
                {isTeacher && (
                  <Button onClick={() => setOpen(true)}>Create Course</Button>
                )}
              </CardContent>
            </Card>
          )}
        </>
      )}
    </div>
  );
}
