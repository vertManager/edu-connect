import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { useAuth } from "@/context/auth-context";
import { useState, useMemo } from "react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function Assignments() {
  const { user } = useAuth();
  const [statusFilter, setStatusFilter] = useState("all");
  const [courseFilter, setCourseFilter] = useState("all");
  
  // Fetch assignments
  const { data: assignments, isLoading } = useQuery({
    queryKey: ['/api/assignments'],
    refetchOnWindowFocus: false,
  });
  
  // Fetch courses
  const { data: courses } = useQuery({
    queryKey: ['/api/courses'],
    refetchOnWindowFocus: false,
  });
  
  // Filter assignments based on selected filters
  const filteredAssignments = useMemo(() => {
    if (!assignments) return [];
    
    return assignments.filter(assignment => {
      const matchesStatus = statusFilter === "all" || assignment.status === statusFilter;
      const matchesCourse = courseFilter === "all" || assignment.course.id.toString() === courseFilter;
      return matchesStatus && matchesCourse;
    });
  }, [assignments, statusFilter, courseFilter]);
  
  // Group assignments
  const upcomingAssignments = useMemo(() => {
    return filteredAssignments.filter(a => 
      a.status !== 'completed' && a.status !== 'submitted' && a.status !== 'graded'
    );
  }, [filteredAssignments]);
  
  const completedAssignments = useMemo(() => {
    return filteredAssignments.filter(a => 
      a.status === 'completed' || a.status === 'submitted' || a.status === 'graded'
    );
  }, [filteredAssignments]);
  
  const isTeacher = user?.role === 'teacher' || user?.role === 'admin';
  
  return (
    <div>
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold text-neutral-900 dark:text-neutral-100">Assignments</h1>
          <p className="text-neutral-600 dark:text-neutral-400">
            {isTeacher ? "Manage and grade student assignments" : "View and submit your assignments"}
          </p>
        </div>
        
        {isTeacher && (
          <Button asChild>
            <Link href="/assignments/create">Create Assignment</Link>
          </Button>
        )}
      </div>
      
      {/* Filter controls */}
      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <div className="flex-1">
          <Select value={courseFilter} onValueChange={setCourseFilter}>
            <SelectTrigger>
              <SelectValue placeholder="Filter by course" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Courses</SelectItem>
              {courses?.map(course => (
                <SelectItem key={course.id} value={course.id.toString()}>
                  {course.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        <div className="flex-1">
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger>
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="not_started">Not Started</SelectItem>
              <SelectItem value="in_progress">In Progress</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
              <SelectItem value="submitted">Submitted</SelectItem>
              <SelectItem value="graded">Graded</SelectItem>
              <SelectItem value="overdue">Overdue</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      
      <Tabs defaultValue="upcoming">
        <TabsList className="mb-6">
          <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
          <TabsTrigger value="completed">Completed</TabsTrigger>
        </TabsList>
        
        <TabsContent value="upcoming">
          {isLoading ? (
            <div className="space-y-4">
              {[1, 2, 3].map(i => (
                <Card key={i} className="animate-pulse">
                  <CardContent className="p-6">
                    <div className="h-5 bg-neutral-200 dark:bg-neutral-800 rounded w-1/3 mb-4"></div>
                    <div className="h-4 bg-neutral-200 dark:bg-neutral-800 rounded w-full mb-2"></div>
                    <div className="h-4 bg-neutral-200 dark:bg-neutral-800 rounded w-2/3"></div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : upcomingAssignments.length > 0 ? (
            <div className="space-y-4">
              {upcomingAssignments.map(assignment => (
                <Card key={assignment.id}>
                  <CardContent className="p-4">
                    <div className="flex flex-col md:flex-row justify-between gap-4">
                      <div className="flex items-start gap-4">
                        <div className="flex-shrink-0 h-10 w-10 rounded-full bg-primary-100 dark:bg-primary-900/50 flex items-center justify-center text-primary-500 mt-1">
                          <i className="ri-file-text-line"></i>
                        </div>
                        <div className="flex-1">
                          <Link href={`/assignments/${assignment.id}`}>
                            <h3 className="font-medium text-lg mb-1 hover:text-primary-500 transition-colors">
                              {assignment.title}
                            </h3>
                          </Link>
                          <div className="flex flex-wrap gap-3 text-sm mb-2">
                            <span className="flex items-center text-neutral-600 dark:text-neutral-400">
                              <i className="ri-book-open-line mr-1"></i>
                              {assignment.course.name}
                            </span>
                            <span className="flex items-center text-neutral-600 dark:text-neutral-400">
                              <i className="ri-calendar-line mr-1"></i>
                              Due: {new Date(assignment.dueDate).toLocaleDateString()}
                            </span>
                            <span className="flex items-center text-neutral-600 dark:text-neutral-400">
                              <i className="ri-medal-line mr-1"></i>
                              {assignment.points} points
                            </span>
                          </div>
                          
                          <div className={`px-2 py-1 text-xs inline-block rounded-full ${
                            assignment.status === 'not_started'
                              ? 'bg-warning-100 dark:bg-warning-900/30 text-warning-800 dark:text-warning-200'
                              : assignment.status === 'in_progress'
                              ? 'bg-primary-100 dark:bg-primary-900/30 text-primary-800 dark:text-primary-200'
                              : 'bg-error-100 dark:bg-error-900/30 text-error-800 dark:text-error-200'
                          }`}>
                            {assignment.status === 'not_started' ? 'Not Started' : 
                             assignment.status === 'in_progress' ? 'In Progress' : 'Overdue'}
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-center">
                        <Button asChild>
                          <Link href={`/assignments/${assignment.id}`}>
                            {assignment.status === 'not_started' ? 'Start' : 
                             assignment.status === 'in_progress' ? 'Continue' : 'Submit Late'}
                          </Link>
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <div className="rounded-full bg-primary-100 dark:bg-primary-900/20 p-4 mb-4">
                  <i className="ri-task-line text-4xl text-primary-500"></i>
                </div>
                <h3 className="text-lg font-medium mb-2">No Upcoming Assignments</h3>
                <p className="text-center text-neutral-600 dark:text-neutral-400 mb-6 max-w-md">
                  You're all caught up! Check back later for new assignments.
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
        
        <TabsContent value="completed">
          {isLoading ? (
            <div className="space-y-4">
              {[1, 2, 3].map(i => (
                <Card key={i} className="animate-pulse">
                  <CardContent className="p-6">
                    <div className="h-5 bg-neutral-200 dark:bg-neutral-800 rounded w-1/3 mb-4"></div>
                    <div className="h-4 bg-neutral-200 dark:bg-neutral-800 rounded w-full mb-2"></div>
                    <div className="h-4 bg-neutral-200 dark:bg-neutral-800 rounded w-2/3"></div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : completedAssignments.length > 0 ? (
            <div className="space-y-4">
              {completedAssignments.map(assignment => (
                <Card key={assignment.id}>
                  <CardContent className="p-4">
                    <div className="flex flex-col md:flex-row justify-between gap-4">
                      <div className="flex items-start gap-4">
                        <div className="flex-shrink-0 h-10 w-10 rounded-full bg-success-100 dark:bg-success-900/50 flex items-center justify-center text-success-500 mt-1">
                          <i className="ri-check-line"></i>
                        </div>
                        <div className="flex-1">
                          <Link href={`/assignments/${assignment.id}`}>
                            <h3 className="font-medium text-lg mb-1 hover:text-primary-500 transition-colors">
                              {assignment.title}
                            </h3>
                          </Link>
                          <div className="flex flex-wrap gap-3 text-sm mb-2">
                            <span className="flex items-center text-neutral-600 dark:text-neutral-400">
                              <i className="ri-book-open-line mr-1"></i>
                              {assignment.course.name}
                            </span>
                            <span className="flex items-center text-neutral-600 dark:text-neutral-400">
                              <i className="ri-calendar-line mr-1"></i>
                              Submitted: {assignment.submission?.submittedAt ? 
                                new Date(assignment.submission.submittedAt).toLocaleDateString() : 
                                "Not submitted"}
                            </span>
                            {assignment.submission?.grade !== undefined && (
                              <span className="flex items-center text-neutral-600 dark:text-neutral-400">
                                <i className="ri-medal-line mr-1"></i>
                                Grade: {assignment.submission.grade}/{assignment.points}
                              </span>
                            )}
                          </div>
                          
                          <div className={`px-2 py-1 text-xs inline-block rounded-full ${
                            assignment.status === 'graded'
                              ? 'bg-success-100 dark:bg-success-900/30 text-success-800 dark:text-success-200'
                              : 'bg-primary-100 dark:bg-primary-900/30 text-primary-800 dark:text-primary-200'
                          }`}>
                            {assignment.status.charAt(0).toUpperCase() + assignment.status.slice(1).replace('_', ' ')}
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-center">
                        <Button asChild variant="outline">
                          <Link href={`/assignments/${assignment.id}`}>View Submission</Link>
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <div className="rounded-full bg-neutral-100 dark:bg-neutral-800 p-4 mb-4">
                  <i className="ri-file-list-line text-4xl text-neutral-500"></i>
                </div>
                <h3 className="text-lg font-medium mb-2">No Completed Assignments</h3>
                <p className="text-center text-neutral-600 dark:text-neutral-400 mb-6 max-w-md">
                  You haven't completed any assignments yet. Start working on your upcoming assignments.
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
