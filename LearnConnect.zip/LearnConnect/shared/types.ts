import { User, Course, Assignment, Submission, Announcement, Resource, Event, Message } from "./schema";

// Extended types with joined data
export interface CourseWithTeacher extends Course {
  teacher: User;
}

export interface CourseWithEnrollment extends Course {
  teacher: User;
  progress: number;
  enrolledAt: Date;
}

export interface AssignmentWithCourse extends Assignment {
  course: Course;
}

export interface AssignmentWithSubmission extends Assignment {
  course: Course;
  submission?: Submission;
}

export interface SubmissionWithAssignment extends Submission {
  assignment: Assignment;
}

export interface AnnouncementWithAuthor extends Announcement {
  author: User;
  course?: Course;
}

export interface ResourceWithCourse extends Resource {
  course: Course;
  creator: User;
}

export interface EventWithCourse extends Event {
  course?: Course;
  creator: User;
}

export interface MessageWithUsers extends Message {
  sender: User;
  receiver: User;
}

// Auth types
export interface AuthUser {
  id: number;
  username: string;
  name: string;
  email: string;
  role: 'student' | 'teacher' | 'admin';
  profileImage?: string;
}

export interface LoginCredentials {
  username: string;
  password: string;
}

// Dashboard statistics
export interface DashboardStats {
  upcomingAssignments: number;
  todayClasses: number;
  unreadMessages: number;
  newGrades: number;
}
